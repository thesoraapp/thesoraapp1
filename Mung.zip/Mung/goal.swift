//
//  goal.swift
//  Mung
//
//  Created by Jake Dorab on 10/18/16.
//  Copyright © 2016 Color & Space. All rights reserved.
//

import Foundation
import UIKit
import Parse


class goalsClass {
    
    var goalObj: PFObject?
    var objectId : String?
    var goalImagePath : String?
    var goalTitle : String?
    var goalAuthorObject: PFUser?
    var goalAuthorId: String?
    var goalAuthorName : String?
    var goalAuthorImagePath : String?
    var goalLikeCount : Int?
    var goalTarget : Double?
    
    var goalSaveRate : Double?
    
    var curUserLikedBool : Bool?
    
    
    var goalEndDate : String?
    
    var goalCategory : String?
    var goalTags : [WSTag]?
    
    var goalImageFile : UIImage?
    
    init( goal: PFObject? = nil ) {
        
        print("printing goal")
        
        print(goal)
        
        if goal == nil {
            self.goalObj = nil
            self.goalAuthorObject = nil
            self.goalAuthorId = nil
            self.goalImagePath = nil
            self.goalTitle = nil
            self.goalLikeCount = nil
            self.curUserLikedBool = nil
            self.goalCategory = nil
            self.goalCategory = nil
            self.goalTags = nil
            self.goalSaveRate = nil
            self.goalTarget = nil
            self.goalImageFile = nil
            self.goalEndDate = nil
            
        }
        else {
            
            self.goalAuthorObject = goal?["goalAuthor"] as! PFUser?
            self.goalImagePath = goal?["goalImagePath"] as! String?
            self.goalTitle = goal?["goalTitle"] as! String?
            self.goalLikeCount = goal?["goalLikeCount"] as! Int?
            self.goalTarget = goal?["goalTarget"] as! Double?
            self.goalEndDate = goal?["goalEndDate"] as! String?
            self.goalCategory = goal?["goalCategory"] as! String?
            
            //query author info
        
        
            let author = PFQuery(className: "_User")
            author.whereKey("objectId", equalTo: self.goalAuthorObject!.objectId!)
            author.findObjectsInBackground { (objectsAuth, error) in
                
                if error == nil {
                    
                    self.goalAuthorImagePath = objectsAuth?[0]["userImagePath"] as! String?
                    self.goalAuthorName = objectsAuth?[0]["userFullName"] as! String?
                    
                }
            }
        }
    }
    
    
    
    func retrieveGoalObj(goalID: String) {
        
        let goals = PFQuery(className: "goals")
        goals.whereKey("_id", equalTo: goalID)
        goals.findObjectsInBackground { (objects, error) in
        
            if error == nil {
                
                self.objectId = objects?[0]["_id"] as! String?
                self.goalAuthorObject = objects?[0]["_p_goalAuthor"] as! PFUser?
                self.goalImagePath = objects?[0]["goalImagePath"] as! String?
                self.goalTitle = objects?[0]["goalTitle"] as! String?
                self.goalLikeCount = objects?[0]["goalLikes"] as! Int?
                self.goalTarget = objects?[0]["goalTarget"] as! Double?
                self.goalEndDate = objects?[0]["goalEndDate"] as! String?
                

                //query author info
                
                let author = PFQuery(className: "_User")
                author.whereKey("_id", equalTo: self.goalAuthorObject!)
                author.findObjectsInBackground { (objectsAuth, error) in
                
                    print("We have author object")
                    
                    if error == nil {
                    
                    print("We have author object")
                    print(objectsAuth?[0])

                    self.goalAuthorImagePath = objectsAuth?[0]["userImagePath"] as! String?
                    self.goalAuthorName = objectsAuth?[0]["userFullName"] as! String?
                
                    }
                }
            }
        }
    }
    
    func updateGoalClassDB(objectID: String, goalAuthorObject: PFUser? = nil, goalImagePath: String? = nil,
                           goalTitle: String? = nil, goalLikeCount: Int? = nil, goalTarget: Double? = nil,
                           goalEndDate: Date? = nil) {
        
        let query = PFQuery(className: "goals")
        
        query.getObjectInBackground(withId: objectID) { (object, error) in
            if error == nil {
                
                if goalAuthorObject != nil {
                    object?["_p_goalAuthor"] = goalAuthorObject!
                }
                if goalTitle != nil {
                    object?["goalTitle"] = goalTitle!
                }
                if goalLikeCount != nil {
                    object?["goalLikeCount"] = goalLikeCount!
                }
                if goalTarget != nil {
                    object?["goalTarget"] = goalTarget!
                }
                if goalEndDate != nil {
                    object?["goalTarget"] = goalEndDate!
                }
                
            }
            object?.saveInBackground()
        }
    }
    
    func saveGoalClassinDB() {
        
        let goalObj = PFObject(className: "goals")
        
        goalObj["_p_goalAuthor"] = self.goalAuthorObject
        goalObj["goalImagePath"] = self.goalImagePath
        goalObj["goalTitle"] = self.goalTitle
        goalObj["goalTarget"] = self.goalTarget
        goalObj["goalEndDate"] = self.goalEndDate
        goalObj["goalLikeCount"] = self.goalLikeCount
        
        goalObj.saveInBackground()
        
    }
    
}



