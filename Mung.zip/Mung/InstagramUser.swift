//
//  InstagramUser.swift
//  Mung
//
//  Created by Jake Dorab on 11/6/16.
//  Copyright © 2016 Color & Space. All rights reserved.
//

import Foundation
import CoreData

/*
class User: NSManagedObject {
    
    @NSManaged var userID: String
    @NSManaged var accessToken: String
    
}

*/
