//
//  helpers.swift
//  Mung
//
//  Created by Chike Chiejine on 13/01/2017.
//  Copyright © 2017 Color & Space. All rights reserved.
//

import Foundation
import UIKit
import Parse


class helpers {
    
    
    // Animation Styles
    public enum position {
        case  left, right, top, bottom
    }
    
    
    
    
    
    func backButton(sender:UIViewController ) -> UIBarButtonItem {
        
        let viewController = sender

        var backButtonImage = UIImage(named: "arrow-icon")
        let newBackButton = UIBarButtonItem(image: backButtonImage, style: UIBarButtonItemStyle.plain, target: viewController, action: "goBack")
        viewController.navigationItem.leftBarButtonItem = newBackButton

//        viewController.navigationController?.popViewController(animated: true)
        
        return viewController.navigationItem.leftBarButtonItem!
        
    }
    

    
    func tableFooter(sender: UITableViewController) -> UIView {
        
        let viewController = sender
    
    // Table Footer
    
        let footerView = UIView()
        footerView.frame = CGRect(x: 0, y: 0, width: viewController.view.frame.width, height: 90 )
        footerView.backgroundColor = .white
        let footerLogo = UIImageView()
        footerLogo.image = UIImage(named: "logo-icon-vector")
        footerLogo.tintColor = UIColor(red:0.78, green:0.76, blue:0.76, alpha:1.0)
        footerLogo.frame = CGRect(x: (viewController.view.frame.width / 2) - 16, y: (footerView.frame.height / 2) - 16, width: 32, height: 32 )
        footerView.addSubview(footerLogo)
        viewController.tableView.tableFooterView?.tag = 10
        viewController.tableView.tableFooterView = footerView
        
        return sender.tableView.tableFooterView!
        
    }
    
    
    
    func startActivityIndicator(sender:UIViewController, object: UIView, activityIndicator: UIActivityIndicatorView, position: String, start: Bool) -> UIActivityIndicatorView {
        
        print("Indicator")
        
        let superview = object.superview
        
        var xPos = CGFloat()
        var yPos = CGFloat()

        if position == "right"  {
            
            xPos = object.frame.origin.x +  object.frame.width + 20
            yPos = object.frame.origin.y + (object.frame.height / 2) - 22.5
            
        } else if position == "left" {
            
            xPos = object.frame.origin.x - 20
            yPos = object.frame.origin.y + (object.frame.height / 2) - 22.5
            
        } else if position == "center" {
            
            xPos = object.center.x - 22.5
            yPos = object.center.y
            
        } else if position == "top" {
            
            xPos = object.center.x - 22.5
            yPos = (sender.navigationController?.navigationBar.frame.height)! + 20
            
        }
        
    
        activityIndicator.frame = CGRect(x: xPos, y:
            yPos, width: 45, height: 45)
        activityIndicator.backgroundColor = .clear
        activityIndicator.hidesWhenStopped = true
        activityIndicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.gray
        
        if position != "top" {
        
            superview?.addSubview(activityIndicator)
            
        } else {
            
            object.addSubview(activityIndicator)
            
        }
        

        if start {
        
            activityIndicator.startAnimating()
            
        } else {
            
            activityIndicator.stopAnimating()
            
        }
        

        return activityIndicator
        
    }

    
    
    
    
    
    
    
    
    
    
}
