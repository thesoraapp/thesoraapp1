//: Playground - noun: a place where people can play

import UIKit
import Parse


var str = "Hello, playground"
