//
//  goalsSetup3ViewController.swift
//  Mung
//
//  Created by Chike Chiejine on 02/01/2017.
//  Copyright © 2017 Color & Space. All rights reserved.
//

import UIKit
import Parse
import SCLAlertView



class goalsSetup3ViewController: UITableViewController, UIGestureRecognizerDelegate {
    
    
    let kInfoTitle = "Authorize Payments"
    let kSubtitle = "Start investing today and get to your goals even quicker."
    
    
    //var goalObject = ["user": PFUser.current(), "goalCategory": String(), "goalTitle": String(), "goalImageUrl": String(), "goalImage": UIImage(), "goalTags": [WSTag](), "goalPrice": Double(), "goalDuration": String(), "risk": String()] as [String : Any]
    
    var goalObject : goalsClass
    
    
    var selectedGoal : PFObject?
    var editMode = false 
    
    var duration = String()
    
    
    @IBOutlet weak var inputCellOne: UITableViewCell!
    
    @IBOutlet weak var goalDeadline: UITextField!
    @IBOutlet weak var goalLabelButton: UIButton!
    @IBOutlet weak var goalStepper: GMStepper!
    
    @IBOutlet weak var goalTitle: UILabel!
    @IBOutlet weak var goalImageExample: UIImageView!
    @IBOutlet weak var exampleGoalCell: UITableViewCell!
    
    var goalCurDepositRate: Int?
    var goalTarget: Double?
    var goalEndDate: Date?
    
    var calActivityIndicator = UIActivityIndicatorView()
    var paymentsActivityIndicator = UIActivityIndicatorView()
    
    let overlayGradient = CAGradientLayer()
    

    
    
    var doneButton = UIButton()
    var authButton = UIButton()

    // Calender
    
    // Initiate tap geture recognizer object
    let tapGesture : UITapGestureRecognizer = UITapGestureRecognizer()
    var calendarOverlay = UIView()
    var calendar =  FSCalendar()
    var withCalendar = false
    
    let formatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd"
        return formatter
    }()
    

    
    
    
    let gregorian: NSCalendar! = NSCalendar(calendarIdentifier:NSCalendar.Identifier.gregorian)
    
    
    @IBAction func goalEndAction(_ sender: Any) {
        
     
        let windowCount = UIApplication.shared.windows.count
        UIApplication.shared.windows[windowCount-1].addSubview(calendarOverlay)
        UIApplication.shared.windows[windowCount-1].addSubview(self.calendar)

   

    }
    
    @IBAction func authoriseAction(_ sender: Any) {
        
        self.view.endEditing(true)
        
        let appearance = SCLAlertView.SCLAppearance(
            
            
            kCircleHeight: 48,
            kCircleIconHeight: 32,
            kTitleFont: UIFont(name: "Proxima Nova Soft", size: 20 )!,
            kTextFont: UIFont(name: "Proxima Nova Soft", size: 14 )!,
            kButtonFont: UIFont(name: "Proxima Nova Soft", size: 14 )!,
            showCloseButton: false,
            dynamicAnimatorActive: false
            
            
        )
        
        let icon = UIImageView()
        icon.image = UIImage(named:"sora-logo")
        icon.tintColor = .white
        
        let color = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0)
        
        let alert = SCLAlertView(appearance: appearance)
        alert.addButton("Later") {
            
            print("Second button tapped")
            
            
            // Stop activity indicator whilst user is being signed up
            let vC = self.storyboard?.instantiateViewController(withIdentifier: "home")

            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            appDelegate.window?.rootViewController = vC
            
            
            
            
        }
        alert.addButton("Authorize", target:self, selector:#selector(userAuthroisation))
        
        _ = alert.showCustom(kInfoTitle, subTitle: kSubtitle, color: color, icon: icon.image!)
        
}
    
    

    func userAuthroisation() {
        
        //#FINALAUTHORISATION
        // Final Goal set Up
        
    }
    
    
    // function - increase count when screen tapped.
    func increaseCount(){
        
        print("TAPPED")
        print("COUNTINCREASE")
        
        print("A")
        print(self.goalStepper.value)
        
        // ADD MORE MONEY
        let curDate = Date()
        let currentDate = self.calendar.selectedDate
        var daysRemain = Double((self.goalEndDate?.days(from: curDate))!)
        
        print("B")
        print(daysRemain)
        
        var currentStepperAmount = Double(self.goalStepper.value)
        daysRemain += 1
        
        print("C")
        print(daysRemain)
        
        
        var newStepperAmount = (currentStepperAmount * daysRemain) * -1
        
        print("D")
        print(newStepperAmount)
        
        print("E")
        print(Double(newStepperAmount))
        
        self.withCalendar = true
        self.goalStepper.value.add(newStepperAmount)
        
        print("F")
        print(self.goalStepper.value)

      
        
        self.calendar.removeFromSuperview()
        self.calendarOverlay.removeFromSuperview()
        
    }
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
    
        
        if editMode {
        
            self.goalStepper.value =  Double(self.goalCurDepositRate!)
            self.calendar.currentPage = self.goalEndDate!
            self.calendar.select(self.goalEndDate!)
            self.duration = stringFromDate(date: self.goalEndDate! as NSDate, format: self.formatter.dateFormat)
            self.goalLabelButton.setTitle(self.duration, for: .normal)
            
            
        } else {
            
            
            
            
            
            
        }
        
        //Gradient Overlay
        
        overlayGradient.colors = [UIColor.clear.cgColor, UIColor.black.cgColor]
        overlayGradient.locations = [0.0, 0.9]
        overlayGradient.frame = CGRect(x: 0, y: 2, width: view.frame.width, height: exampleGoalCell.frame.height)
        goalImageExample.layer.insertSublayer(overlayGradient, at: 8)
        // Amount Stepper
        goalStepper.addTarget(self, action: #selector(self.stepperValueChanged), for: .valueChanged)
        goalStepper.labelFont = UIFont(name: "ProximaNovaSoft-Bold", size: 16)!
        
        
        // set tap gesture recognizer delegte
        self.tapGesture.delegate = self
        self.tapGesture.numberOfTapsRequired = 1
        // set tap gesture target
        self.tapGesture.addTarget(self, action: #selector(self.increaseCount))
        
        
        // Calender overlay
        
        
        calendarOverlay.frame = self.view.frame
        calendarOverlay.backgroundColor = UIColor(red:0.00, green:0.00, blue:0.00, alpha:0.8)
        calendarOverlay.isHidden = false
        // add tap gesture recognizer into view
        self.calendarOverlay.addGestureRecognizer(self.tapGesture)
//        self.view.addSubview(calendarOverlay)
        
        
        //Button
        
        doneButton.frame = CGRect(x: self.view.frame.width / 2 -  60, y: self.view.frame.height - 90, width: 120, height: 40)
        doneButton.backgroundColor = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0)
        doneButton.tintColor = .white
        doneButton.titleLabel?.font =  UIFont(name: "Proxima Nova Soft", size: 16 )!
        doneButton.layer.cornerRadius = 5
        doneButton.setTitle("Done", for: UIControlState.normal)
        doneButton.isHidden = true
        doneButton.addTarget(self, action:#selector(self.increaseCount), for: UIControlEvents.touchUpInside)
        calendarOverlay.addSubview(doneButton)
        
        //Calender 
        
        print(calendar.frame.height)
//        calendar.frame = calendar.frame
        calendar.frame = CGRect(x: 15, y: self.view.frame.height / 2 - 150, width: self.view.bounds.width - 30, height: 300)
        calendar.layer.cornerRadius = 10
        calendar.layer.masksToBounds = true
        calendar.dataSource = self
        calendar.delegate = self
        calendar.backgroundColor = UIColor.white
        calendar.tintColor = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0) //Light blue
        calendar.appearance.selectionColor = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0) //Light blue
        calendar.appearance.headerTitleColor = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0) //Light
        calendar.appearance.weekdayTextColor =  UIColor(red:0.13, green:0.13, blue:0.13, alpha:1.0) // Dark Gray
        calendar.appearance.subtitleDefaultColor = UIColor(red:0.13, green:0.13, blue:0.13, alpha:1.0) // Dark Gray
        calendar.appearance.headerTitleFont = UIFont(name: "Proxima Nova Soft", size: 18 )!
        calendar.appearance.subtitleFont = UIFont(name: "Proxima Nova Soft", size: 14 )!
        calendar.scopeGesture.isEnabled = false
        calendar.allowsMultipleSelection = false
        calendar.allowsSelection = true
//        self.view.addSubview(calendar)
        
        
        self.goalLabelButton.layer.cornerRadius = 5
        
        authButton.setTitle("Finish", for: UIControlState.normal)
        authButton.tintColor = UIColor(red:0.13, green:0.13, blue:0.13, alpha:1.0)
        authButton.isEnabled  = true
        authButton.backgroundColor = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0) //Light blue
        authButton.frame = CGRect(x: 0, y: self.view.frame.height - 55, width: self.view.frame.width, height: 55)
        authButton.addTarget(self, action: #selector(self.authoriseAction), for: UIControlEvents.touchUpInside)
        

        
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        

        
    }
    
    
    func goBack() {
        
        if !(self.editMode) {
            
            // SETUP MODE ACTIVE
        
            let stepTwo = self.storyboard?.instantiateViewController(withIdentifier: "bankSetup") as! BankSetupViewController
//            stepTwo.goalObject = self.goalObject
            self.navigationController?.show(stepTwo, sender: self)
            
            // END SETUP MODE
            
        } else {
            
            // EDIT MODE ACTIVE
            
            
            self.navigationController?.popViewController(animated: true)
            
            
            // END SETUP MODE
            
        }
        
    }
    
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        
        let windowCount = UIApplication.shared.windows.count
        UIApplication.shared.windows[windowCount-1].addSubview(authButton)
        

        
        
        if !(self.editMode) {

            if self.goalObject.goalTitle == "" {
            
                self.goalTitle.text = "Example: Golden State Tickets"
        
            } else {
            
                self.goalTitle.text =  self.goalObject.goalTitle
            
            }
        
            if self.goalObject.goalImagePath != nil {
                if let imageURL = self.goalObject.goalImagePath {
                    if  imageURL != nil {
                    
                        print("IMAGE AVAILABLE")
                    
                        self.goalImageExample.af_setImage(withURL:URL(string: imageURL )!, placeholderImage: UIImage(named:"no-image-bg"), filter: nil,imageTransition: .crossDissolve(0.2), runImageTransitionIfCached: true, completion: nil)
                    
                    } else {
                    
                        print("IMAGE NOT AVAILABLE")
                    
                        self.goalImageExample.image = UIImage(named:"no-image-bg")
                    
                    
                    }
                
                }
            } else {

                    if let image = self.goalObject.goalImageFile {
                        
                        self.goalImageExample.image = image
                        
                    }
            }
            
            
            // END SETUP MODE
        
        } else {
            
            // EDIT MODE ACTIVE
            
            helpers().backButton(sender: self)

            self.goalTitle.text = self.selectedGoal?["goalTitle"] as! String
 
      
                if let imageURL = self.selectedGoal?["goalImagePath"] as? String {
                    
         
                        print("IMAGE AVAILABLE")
                        
                        self.goalImageExample.af_setImage(withURL:URL(string: imageURL )!, placeholderImage: UIImage(named:"no-image-bg"), filter: nil,imageTransition: .crossDissolve(0.2), runImageTransitionIfCached: true, completion: nil)
             
                }
            
            // END SETUP MODE
            
            
        
        }

        

        print("GOALS AFTER")
        print(goalObject)
        
    }

    
    override func viewWillDisappear(_ animated: Bool) {
        
        
        authButton.removeFromSuperview()
        
        
    }
    
    
    
    func stepperValueChanged(stepper: GMStepper) {
        

        
        //#RECIEVESTEPPERVALUES
        
        if !(withCalendar) {
        
        
            print(stepper.value, terminator: "")
            
            self.goalObject.goalTarget = stepper.value
            
            // ADD MORE DAYS
            let curDate = Date()
            var selectedDate = self.calendar.selectedDate
            var daysRemain = self.goalEndDate?.days(from: curDate)
            daysRemain! += 1
            var newDate = selectedDate.addingTimeInterval(TimeInterval(daysRemain! * 86400))
            _ = newDate
            
            self.calendar.setCurrentPage(newDate, animated: true)
            self.calendar.select(newDate)
            
            self.duration = stringFromDate(date: newDate as NSDate, format: self.formatter.dateFormat)
            self.goalLabelButton.setTitle(self.duration, for: .normal)
            
            
            print("NEWDATE")
            print(newDate)
            

            
        } else {
            
            
            self.withCalendar = false
            
        }
        
        //editing

    }
    
    
    
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        if indexPath.row == 0 {
            
            cell.separatorInset = UIEdgeInsets.zero
            cell.indentationWidth = 0
            cell.layoutMargins = UIEdgeInsets.zero
            tableView.separatorStyle = .singleLine
            
        }
        
        tableView.separatorStyle = .none
        
        
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let stepOne = segue.destination as? goalsSetupViewController {
            print("STEP1OBJECT")
            print(stepOne.goalObject)
            print("STEP2OBJECT")
            print(self.goalObject)
            stepOne.goalObject = self.goalObject
        } else if let stepTwo = segue.destination as? goalsSetup2ViewController {
            stepTwo.goalObject = self.goalObject
        } else if let stepThree = segue.destination as? goalsSetup3ViewController {
            stepThree.goalObject = self.goalObject
        } else if let stepFour = segue.destination as? goalsSetup4ViewController {
            stepFour.goalObject = self.goalObject
        } else if let bankSetup = segue.destination as? BankSetupViewController {
            
            
            
        }
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }




}





extension goalsSetup3ViewController: FSCalendarDataSource, FSCalendarDelegate {
    

    func minimumDate(for calendar: FSCalendar) -> Date {
        
        print("MIN")
        
        let today = Date()
        let todayString = stringFromDate(date: today as NSDate, format: self.formatter.dateFormat)
        
        return self.formatter.date(from: todayString)!
    }
    
    func maximumDate(for calendar: FSCalendar) -> Date {
        
        print("MAX")
        
        return self.formatter.date(from: "2019/01/31")!
    }
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        
        //#RECIEVEDATES
        
        print(monthPosition)
        print(date)
        print(stringFromDate(date: date as NSDate, format: self.formatter.dateFormat))
        self.duration = stringFromDate(date: date as NSDate, format: self.formatter.dateFormat)
        self.goalLabelButton.setTitle(self.duration, for: .normal)
        
        doneButton.isHidden = false

        self.goalObject.goalEndDate = self.duration
        
        if self.goalStepper.value != 0 {
            
         //  self.nextButton.isEnabled = true
          //  self.nextButton.backgroundColor = UIColor(red:0.17, green:0.82, blue:0.25, alpha:1.0)
            
        }
        

        
        if monthPosition == .previous || monthPosition == .next {
            calendar.setCurrentPage(date, animated: true)
            
        }
        
    }
    
    // Update your frame
    func calendar(_ calendar: FSCalendar, boundingRectWillChange bounds: CGRect, animated: Bool) {
        
        self.calendar.frame = CGRect(x: 0, y: self.view.frame.maxY - self.calendar.frame.height, width: bounds.width, height: bounds.height)
    }
    
    
    
}








