//
//  goalsSetup2ViewController.swift
//  Mung
//
//  Created by Chike Chiejine on 02/11/2016.
//  Copyright © 2016 Color & Space. All rights reserved.
//

import UIKit
import Parse
import SCLAlertView


// UIColor(red:0.67, green:0.67, blue:0.67, alpha:1.0) // Light Grey
// UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0) //Light blue




class goalsSetup2ViewController: UITableViewController, UITextFieldDelegate, UIGestureRecognizerDelegate,UIViewControllerTransitioningDelegate  {
    
    
    
    let kSuccessTitle = "Congratulations"
    let kErrorTitle = "Connection error"
    let kNoticeTitle = "Notice"
    let kWarningTitle = "Warning"
    let kInfoTitle = "Connect Link Up"
    let kSubtitle = "We need to connect your bank account to do the maths on when you can finish your goal. No payments are being made just yet!"
    let kDefaultAnimationDuration = 2.0
    
    @IBOutlet weak var exampleGoalCell: UITableViewCell!
    @IBOutlet weak var inputCellOne: UITableViewCell!
    @IBOutlet weak var inputCellTwo: UITableViewCell!
    @IBOutlet weak var inputCellThree: UITableViewCell!
    
    var inputCells: [UITableViewCell]?
    
    @IBOutlet weak var goalTitle: UILabel!
    @IBOutlet weak var goalImageExample: UIImageView!
   
    @IBOutlet weak var priceIcon: UIImageView!
    @IBOutlet weak var nameIcon: UIImageView!
    @IBOutlet weak var tagIcon: UIImageView!
    
    
    
    
    @IBOutlet weak var amountStepper: GMStepper!
    
    
    //var goalObject = ["user": PFUser.current(), "goalCategory": String(), "goalTitle": String(), "goalImageUrl": String(), "goalImage": UIImage(), "goalTags": [WSTag](), "goalPrice": Double(), "goalDuration": String(), "risk": String()] as [String : Any]
    
    var goalObject : goalsClass
    
    @IBOutlet weak var goalName: UITextField!
//    @IBOutlet weak var goalTags: UITextField!
    let toolBar = UIToolbar()
    var instaUpload = false
    var activeField: UITextField?
    var activeFieldCell: UITableViewCell?
    
    var inputLabelOne = UILabel()
    var inputLabelTwo = UILabel()
    
    var underlineOne = UIView()
    var underlineTwo = UIView()
    var pickerView = UIPickerView()
    let nextButton = UIButton()
    
    var tags_array =  [String]()
    let tagsField = WSTagsField()
    
    let overlayGradient = CAGradientLayer()
    let uploadButton = UIButton()
    
    @IBAction func doneButton(_ sender: Any) {
        
        
        nextPreviousField(sender: sender as! UIBarButtonItem)
        
        
    }
    
    func goBack() {
        
        let stepOne = self.storyboard?.instantiateViewController(withIdentifier: "step1") as! goalsSetupViewController
        stepOne.goalObject = self.goalObject
        self.navigationController?.show(stepOne, sender: self)
        
    }
    
    
    // Initiate tap geture recognizer object
    let tapGesture : UILongPressGestureRecognizer = UILongPressGestureRecognizer()
    

    
    func uploadAction() {
        
        showActionSheet()

        
    }
    


    override func viewDidLoad() {
        super.viewDidLoad()
        

        
        amountStepper.addTarget(self, action: #selector(self.stepperValueChanged), for: .valueChanged)
        amountStepper.labelFont = UIFont(name: "HelveticaNeue-Light", size: 18)!

        
        let xPos = (view.bounds.width / 2) - 45
        let yPos = (exampleGoalCell.frame.height / 2) - 45
        
        //Gradient Overlay
        
        overlayGradient.colors = [UIColor.clear.cgColor, UIColor.black.cgColor]
        overlayGradient.locations = [0.0, 0.9]
        overlayGradient.frame = CGRect(x: 0, y: 2, width: view.frame.width, height: exampleGoalCell.frame.height)
        
        
        

        
        // upload button
        
        uploadButton.frame =  CGRect(x: xPos , y: yPos, width: 90, height: 90) //Center positioned
        uploadButton.addTarget(self, action:#selector(self.uploadAction), for: .touchUpInside)
        uploadButton.layer.cornerRadius = 45
        let buttonImage = UIImage(named: "upload-camera")
        uploadButton.setImage(buttonImage, for: .normal)
        uploadButton.backgroundColor = UIColor(red:0.00, green:0.00, blue:0.00, alpha:0.7)
        uploadButton.tintColor = .white
        uploadButton.isHidden = true
        exampleGoalCell.addSubview(uploadButton)
        
        
        // exampleGoalCell.addGestureRecognizer(tapGesture)
        //exampleGoalCell.addSubview(blurEffectView)
        
        
        var backButtonImage = UIImage(named: "arrow-icon")
        let newBackButton = UIBarButtonItem(image: backButtonImage, style: UIBarButtonItemStyle.plain, target: self, action: "goBack" )
        self.navigationItem.leftBarButtonItem = newBackButton

        
        
        //Set icon colour
        nameIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0)
        tagIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0)
        priceIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0)
        
        
        
        // Set up textfields delegate
        
        self.goalName.delegate = self
        self.goalName.tag = 0
        self.tagsField.tag = 1
        
        self.goalName.addTarget(self, action: #selector(self.didChangeText), for: .editingChanged)
        

        self.tableView.tableFooterView = UIView()
        
        
        // Setup pickerview toolbar
        
        inputCells = [inputCellOne, inputCellTwo, inputCellThree]
        
        
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0)
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action:#selector(self.nextPreviousField))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let nextButton = UIBarButtonItem(title: "Next", style: UIBarButtonItemStyle.plain, target: self, action: #selector(self.nextPreviousField))
        let prevButton = UIBarButtonItem(title: "Prev", style: UIBarButtonItemStyle.plain, target: self, action: #selector(self.nextPreviousField))
        prevButton.tag = 2
        nextButton.tag = 1
        doneButton.tag = 0
        
        toolBar.setItems([doneButton, spaceButton, prevButton, nextButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        
        
   // Get positions
   let inputOneOriginY = self.goalName.frame.origin.y
   let inputOneOriginX = self.goalName.frame.origin.x
   let inputWidth = self.goalName.frame.width
   let inputOneHeight = self.inputCellOne.frame.height
   let inputOneWidth = self.view.bounds.width
        
        // Register keyboard notifications
        
    NotificationCenter.default.addObserver(self, selector: #selector(goalsSetup2ViewController.keyboardDidShow(_:)), name: NSNotification.Name.UIKeyboardDidShow, object: nil)
    NotificationCenter.default.addObserver(self, selector: #selector(goalsSetup2ViewController.keyboardWillBeHidden(_:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
    // Setup Next Button
        
   // nextButton.setTitle("Next Step", for: UIControlState.normal)
    //nextButton.tintColor = UIColor(red:0.13, green:0.13, blue:0.13, alpha:1.0)
    //nextButton.isEnabled = false
    //nextButton.backgroundColor = UIColor(red:0.76, green:0.76, blue:0.76, alpha:1.0)
    //nextButton.frame = CGRect(x: 0, y: self.view.frame.height, width: self.view.frame.width, height: 55)
   // nextButton.addTarget(self, action: #selector(self.nextButtonAction), for: UIControlEvents.touchUpInside)

   // Create underline
    underlineOne.frame = CGRect(x: 10, y: inputOneHeight - 4, width: inputOneWidth - 20, height: 0.5)
    underlineOne.backgroundColor = UIColor.lightGray
        
   //Add subviews
   //self.inputCellOne.addSubview(underlineOne)
   // Create underline
   underlineTwo.frame = CGRect(x: 10, y: inputOneHeight - 4, width: inputOneWidth - 20 , height: 0.5)
   underlineTwo.backgroundColor = UIColor.lightGray
   //Add subviews
  // self.inputCellTwo.addSubview(underlineTwo)
        
        

        
        
        // Add tag
        
        let midCell = (inputOneHeight / 2) - 27
        
        tagsField.inputAccessory = toolBar
        tagsField.backgroundColor = .clear
        tagsField.frame = CGRect(x: 79, y: midCell , width: inputOneWidth - 89, height: 35)
        tagsField.spaceBetweenTags = 10.0
        tagsField.placeholder = "Example: BASKETBALL NBA TEAMS"
        tagsField.font = UIFont(name: "Proxima Nova Soft", size: 14)
        tagsField.keyboardType = .twitter
        //   tagsField.text = UITextAutocapitalizationType.allCharacters
        tagsField.tintColor = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0) //Light blue
        tagsField.textColor = .white
        tagsField.fieldTextColor = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0) //Light blue
        tagsField.selectedColor = .white
        tagsField.selectedTextColor =  UIColor(red:0.06, green:0.44, blue:0.60, alpha:1.0) //Dark blue
        
        self.inputCellThree.addSubview(tagsField)
        
        // Events
        
        tagsField.onDidChangeText = { _ in
            
            self.goalObject.goalTags = self.tagsField.tags
            
        }
        
        tagsField.onDidBeginEditing = { _ in
            
            self.activeFieldCell = self.inputCellThree
            self.underlineTwo.backgroundColor = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0) //Light blue
            
            self.tagIcon.tintColor = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0) //Light blue
            //Set icon colour
            self.nameIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0) // Gray
            self.priceIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0) //Gray
        }
        

        
        tagsField.onDidEndEditing = { _ in
            
            self.activeFieldCell = nil
            self.underlineTwo.backgroundColor = UIColor(red:0.67, green:0.67, blue:0.67, alpha:1.0)
            self.tagIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0) // Gray
        }
        
        
        tagsField.onDidAddTag = { _ in
            

            
        }

        
        tagsField.onDidChangeHeightTo = { sender, height in
            print("HeightTo \(height)")
            
             self.underlineTwo.frame = CGRect(x: 10, y: height + 60, width: inputOneWidth - 20 , height: 0.5)
            
            
            self.tableView.estimatedRowHeight = self.tableView.rowHeight + height + 60
            self.tableView.rowHeight = UITableViewAutomaticDimension
        
          
            
        }
        
   
        
        
    }
    
    
    var selectedIndex: Int = 0
    

    
    func nextPreviousField(sender: UIBarButtonItem ){
    
        var previousIndex = selectedIndex
        selectedIndex = sender.tag
        

     
        if sender.tag == 2 {
            
            self.activeFieldCell = inputCells?[previousIndex]
            setUpCell()
            
        } else if sender.tag == 1 {
            
            
            self.activeFieldCell = inputCells?[selectedIndex]
            setUpCell()
            
        } else {
            
            selectedIndex = 0

            print("DONE")
            self.view.endEditing(true)
            
//            segue.destination as? goalsSetup3ViewController {
//            stepThree.goalObject = self.goalObject
            
           
            let appearance = SCLAlertView.SCLAppearance(
                
         
                kCircleHeight: 48,
                kCircleIconHeight: 32,
                kTitleFont: UIFont(name: "Proxima Nova Soft", size: 20 )!,
                kTextFont: UIFont(name: "Proxima Nova Soft", size: 14 )!,
                kButtonFont: UIFont(name: "Proxima Nova Soft", size: 14 )!,
                showCloseButton: false,
                dynamicAnimatorActive: false
                
                
                )
            
            let icon = UIImageView()
            icon.image = UIImage(named:"sora-logo")
            icon.tintColor = .white

            let color = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0)
            
            let alert = SCLAlertView(appearance: appearance)

            alert.addButton("Connect me", target:self, selector:#selector(proceedButton))
            _ = alert.showCustom(kInfoTitle, subTitle: kSubtitle, color: color, icon: icon.image!)
    
            
            
        }
   
        
    }
    
    func proceedButton() {
        print("First button tapped")
        //BANK SEGUE
        
        let nextvC = self.storyboard?.instantiateViewController(withIdentifier: "bankSetup") as! BankSetupViewController
//        nextvC.goalObject = self.goalObject
        self.show(nextvC, sender: self)
        
        
    }
    
    
    func setUpCell() {
        
        if activeFieldCell?.tag == 1 {
            
            print("DID SELECT 1")
            self.goalName.becomeFirstResponder()
            underlineTwo.backgroundColor = UIColor(red:0.06, green:0.44, blue:0.60, alpha:1.0)
            
        } else if activeFieldCell?.tag == 2  {
            
            print("DID SELECT 2")
            self.view.endEditing(true)
            self.activeFieldCell = self.inputCellTwo
            priceIcon.tintColor  = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0) //Light blue
            tagIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0)
            nameIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0)
            
        } else if activeFieldCell?.tag == 3 {
            
            print("DID SELECT 3")
            self.tagsField.beginEditing()
            

            
        }
        
        
    }
    
    
    
    
    func stepperValueChanged(stepper: GMStepper) {
        
        print(stepper.value, terminator: "")
        self.view.endEditing(true)
        self.goalObject.goalSaveRate = stepper.value
        
        self.priceIcon.tintColor = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0) //Light blue
        self.nameIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0) // Gray
        self.tagIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0) // Gray

        
        
        
    }
    
 
    func nextButtonAction(sender: UIButton) {
        
        let indexPath = sender.tag
        let nextvC = self.storyboard?.instantiateViewController(withIdentifier: "bankSetup") as! BankSetupViewController
//        nextvC.goalObject = self.goalObject
        self.show(nextvC, sender: self)
        
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        
        self.goalName.becomeFirstResponder()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        print("GOALS BEFORE")
        print(goalObject)
        
        //Set icon colour
        nameIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0)
        tagIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0)
        priceIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0)
        

        self.nextButton.removeFromSuperview()
        
        // Show goal title
        
        if self.goalObject.goalTitle == "" {
            
            self.goalTitle.text = "Example: Golden State Tickets"
            
            
        } else {
        
            self.goalTitle.text =  self.goalObject.goalTitle
            
        }
        
        
        
        
        UIView.animate(withDuration: 0.5, animations: {
            self.uploadButton.isHidden = false
            
        })
        
        // Show uploaded goal image
        
        
        if self.goalObject.goalImagePath == "" {
        
            self.uploadButton.backgroundColor = UIColor(red:0.00, green:0.00, blue:0.00, alpha:0.4)
            
            
            if let imageURL = self.goalObject.goalImagePath {
        

                    print("IMAGE AVAILABLE")
                let xPos = view.bounds.width - 80
                let yPos = exampleGoalCell.frame.height - 80
                
                if uploadButton.frame.height != 70 {
                
                UIView.animate(withDuration: 0.3, animations: {
                    self.uploadButton.isHidden = false
                    self.uploadButton.frame =  CGRect(x: xPos , y: yPos, width: 70, height: 70) //Bottom right positioned
                    self.uploadButton.layer.cornerRadius = 35
 
                })
                    
                }

                    self.goalImageExample.layer.insertSublayer(overlayGradient, at: 8)
                    self.goalImageExample.af_setImage(withURL:URL(string: imageURL )!, placeholderImage: UIImage(named:"no-image-bg"), filter: nil,imageTransition: .crossDissolve(0.2), runImageTransitionIfCached: true, completion: nil)
                
           
            
            }
            
        }   else {
            

//        } else if self.goalObject["goalImage"] as? UIImage != nil {
//            
//            if let image = self.goalObject["goalImage"] as? UIImage {
//                
//                self.goalImageExample.image = image
//                
//            }
//            
//            
//        } else {
            
            
            //Might not need
            
//            uploadButton.backgroundColor = UIColor(red:0.00, green:0.00, blue:0.00, alpha:0.7)
//            self.overlayGradient.removeFromSuperlayer()
            
            print("NO IMAGE")

            
            self.goalImageExample.image = UIImage(named:"no-image-bg")
            
        }
        
    
        
        if self.amountStepper.value != 0  {
            
            self.amountStepper.value = self.goalObject.goalTarget ?? 00.0
            
            
        } else {
            
            self.amountStepper.value = 0

            
        }

        
        
//        self.goalObject.goalTitle = self.goalObject["goalTitle"]
//        self.goalObject["goalTags"] = self.goalObject["goalTags"]
        self.goalName.text = self.goalObject.goalTitle
        self.tagsField.addTags(self.goalObject.goalTags!)

        print("GOALS AFTER")
        print(goalObject)
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        self.nextButton.removeFromSuperview()

        
    }
    
    
    
    func didChangeText(textField:UITextField) {
        
        self.goalObject.goalTitle = textField.text
        
        self.goalTitle.text = textField.text
        
        if textField.text != "" && (textField.text?.characters.count)! > 5 {
            
            
            print("NOW TYPING")
            self.nextButton.isEnabled = true
            self.nextButton.backgroundColor = UIColor(red:0.17, green:0.82, blue:0.25, alpha:1.0)
            
        }
        
        if textField.text == "" {
            
            print("NOW EMPTY")
            
            self.goalTitle.text = "Example: Golden State Tickets"
            
            self.nextButton.isEnabled = false
            self.nextButton.backgroundColor = UIColor(red:0.76, green:0.76, blue:0.76, alpha:1.0)
            
        }
        
        
        
    }

    
   
    // Check textfield status and change accordingly
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        
        
        self.activeField =  nil
        self.activeFieldCell = nil
        
        if  textField.tag == 0 {
            
            textField.resignFirstResponder()
            underlineOne.backgroundColor = UIColor(red:0.67, green:0.67, blue:0.67, alpha:1.0)
            nameIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0) // Gray
            

        } else {
            
            textField.resignFirstResponder()
            underlineTwo.backgroundColor = UIColor(red:0.67, green:0.67, blue:0.67, alpha:1.0)
            tagIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0) // Gray
            
        }
        
        
        
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        textField.inputAccessoryView = toolBar
        
        if  textField.tag == 0 {
            
            self.activeFieldCell = self.inputCellOne
            underlineOne.backgroundColor = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0) //Light blue
            nameIcon.tintColor = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0) //Light blue
            priceIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0)
            
        } else if textField.tag == 1 {
            
            self.activeFieldCell = self.inputCellThree
            underlineTwo.backgroundColor = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0) //Light blue
            tagIcon.tintColor = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0) //Light blue
            priceIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0)
            
        }
        
        self.activeField = textField
        
        
        
    }
    

    
//    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
//        
//        if textField.tag == 1 {
//        
//        tags_array = (textField.text?.components(separatedBy: "."))!
//        
//        }
//        
//        return true
//        
//    }
//    
    
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
 
    
    
        cell.separatorInset = UIEdgeInsets.zero
        cell.indentationWidth = 0
        cell.layoutMargins = UIEdgeInsets.zero
        
        //tableView.separatorStyle = .none
        
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        self.view.endEditing(true)
        
        if  self.activeField?.tag == 0 {
            
            self.activeFieldCell = self.inputCellOne
            underlineOne.backgroundColor = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0) //Light blue
            self.activeField?.becomeFirstResponder()
            
        } else if self.activeField?.tag == 1 {
            
            self.activeFieldCell = self.inputCellThree
            underlineTwo.backgroundColor = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0) //Light blue
            self.activeField?.becomeFirstResponder()
            
        } else {
            
            self.activeFieldCell = self.inputCellTwo
            
        }
        
        if indexPath.row == 1 {
            
            print("DID SELECT 1")
            self.goalName.becomeFirstResponder()
            underlineTwo.backgroundColor = UIColor(red:0.06, green:0.44, blue:0.60, alpha:1.0)
            
        } else if indexPath.row == 2  {
            
            print("DID SELECT 2")
            self.view.endEditing(true)
            self.activeFieldCell = self.inputCellTwo
            priceIcon.tintColor  = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0) //Light blue
            tagIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0)
            nameIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0)
            
            
            
        }else if indexPath.row == 3 {
            
            print("DID SELECT 3")
            self.tagsField.beginEditing()
            
        }
        
        
    }
    
    
    

    
    
    func keyboardDidShow(_ notification: Notification) {
        
        print("Keyboard did show")
        print(self.activeField)
        
        
        if  self.goalName.text != "" {

            self.nextButton.isEnabled = true
            self.nextButton.backgroundColor = UIColor(red:0.17, green:0.82, blue:0.25, alpha:1.0)
            
        }
        
        
        if let activeField = self.activeFieldCell, let keyboardSize = ((notification as NSNotification).userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            
            
            let contentInsets = UIEdgeInsets(top: 0.0, left: 0.0, bottom: keyboardSize.height + self.inputCellOne.frame.height, right: 0.0)
            self.tableView.contentInset = contentInsets
            self.tableView.scrollIndicatorInsets = contentInsets
            
            
            var aRect = self.view.frame
            aRect.size.height -= keyboardSize.size.height
            

            if (!aRect.contains(activeField.frame.origin)) {
                
                self.tableView.scrollRectToVisible(activeField.frame, animated: true)
            }
            
            
            //                self.view.addSubview(self.nextButton)
            var windowCount = UIApplication.shared.windows.count
            UIApplication.shared.windows[windowCount-1].addSubview(self.nextButton);
            self.nextButton.frame = CGRect(x: self.nextButton.frame.origin.x, y: self.view.bounds.height - keyboardSize.height + 10, width: self.nextButton.frame.size.width, height: self.nextButton.frame.size.height)
            

            
        }
        
        
    }
    
    func keyboardWillBeHidden(_ notification: Notification) {
        
        let contentInsets = UIEdgeInsets.zero
        self.tableView.contentInset = contentInsets
        self.tableView.scrollIndicatorInsets = contentInsets
        
        self.nextButton.removeFromSuperview()
        
    }
    
    
    
    
    func registerForKeyboardNotifications()
    {
        //Adding notifies on keyboard appearing
        NotificationCenter.default.addObserver(self, selector: "keyboardWasShown:", name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(goalsSetup2ViewController.keyboardWillBeHidden(_:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    
    func deregisterFromKeyboardNotifications()
    {
        //Removing notifies on keyboard appearing
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let stepOne = segue.destination as? goalsSetupViewController {
            print("STEP1OBJECT")
            print(stepOne.goalObject)
            print("STEP2OBJECT")
            print(self.goalObject)
            stepOne.goalObject = self.goalObject
        } else if let stepTwo = segue.destination as? goalsSetup2ViewController {
            stepTwo.goalObject = self.goalObject
        } else if let stepThree = segue.destination as? goalsSetup3ViewController {
            stepThree.goalObject = self.goalObject
        } else if let stepFour = segue.destination as? goalsSetup4ViewController {
            stepFour.goalObject = self.goalObject
        } else if let bankSetup = segue.destination as? BankSetupViewController {
//            bankSetup.goalObject = self.goalObject
        }
    }

    
 
 override func didReceiveMemoryWarning() {
 super.didReceiveMemoryWarning()
//         Dispose of any resources that can be recreated.
    }
    
    
    // show action sheet
    fileprivate func showActionSheet() {
        
        // create controller with style as ActionSheet
        let alertCtrl = UIAlertController(title: "Upload a Goal Image", message: "Visualize this thing that you want, see it, feel it, believe in it.", preferredStyle: UIAlertControllerStyle.actionSheet)
        
        // create button action
        let InstagramAction = UIAlertAction(title: "Instagram Upload", style: UIAlertActionStyle.default, handler: { (action) in
            
            
           var instaUpload = true
            
           if let instaUploadController = self.storyboard?.instantiateViewController(withIdentifier:
            "gallery") as? PhotoBrowserCollectionViewController {
            
//            instaUploadController.goalObject = self.goalObject
            
             let navController = UINavigationController(rootViewController: instaUploadController)
            
            self.view.endEditing(true)
            
            navController.modalPresentationStyle = UIModalPresentationStyle.custom
            navController.transitioningDelegate = self
            self.navigationController?.present(navController, animated: true, completion: nil)
            
            }
            
        })
        
        
        
        let libraryAction = UIAlertAction(title: "Choose from library", style: UIAlertActionStyle.default, handler: {(action) in
            
            var instaUpload = false
            self.imagePicker(isCamera: false)
            
            
            
        })
        let photoAction = UIAlertAction(title: "Take a photo", style: UIAlertActionStyle.default, handler: {(action) in
            
            
            print("camera Selected...")
            var instaUpload = false
            
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera) == true {
                
                self.imagePicker(isCamera: true)
                
            } else{
                
                self.present(self.showAlert(Title: "Title", Message: "Camera is not available on this Device or accesibility has been revoked!"), animated: true, completion: nil)
                
            }
            
            
        })
        // let deleteAction = UIAlertAction(title: "Delete", style: UIAlertActionStyle.destructive, handler: nil)
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: nil)
        
        // add action to controller
        alertCtrl.addAction(InstagramAction)
        alertCtrl.addAction(libraryAction)
        alertCtrl.addAction(photoAction)
        // alertCtrl.addAction(deleteAction)
        alertCtrl.addAction(cancelAction)
        
        // show action sheet
        self.present(alertCtrl, animated: true, completion: nil)
    }
    
    



}




extension goalsSetup2ViewController:  UIImagePickerControllerDelegate,  UINavigationControllerDelegate {


    func imagePicker(isCamera: Bool){
        
        self.view.endEditing(true)
        
        let image = UIImagePickerController()
        image.delegate = self
        
        if isCamera == false {
            
            image.sourceType = .photoLibrary
            
        } else {
            
            image.sourceType = .camera
        }
        
            image.allowsEditing = false
    
        self.present(image, animated: true, completion: nil)
    
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingImage image: UIImage, editingInfo: [String : AnyObject]?) {
        
        print("IMAGE RECOVERED")
        print(image)
        self.goalObject.goalImageFile = image
        self.goalImageExample.image = image
        
        self.dismiss(animated: true, completion: nil)
    

    }
    
    
    //Show Alert
    
    
    func showAlert(Title : String!, Message : String!)  -> UIAlertController {
        
        let alertController : UIAlertController = UIAlertController(title: Title, message: Message, preferredStyle: .alert)
        let okAction : UIAlertAction = UIAlertAction(title: "Ok", style: .default) { (alert) in
            print("User pressed ok function")
            
        }
        
        alertController.addAction(okAction)
        alertController.popoverPresentationController?.sourceView = view
        alertController.popoverPresentationController?.sourceRect = view.frame
        
        return alertController
    }
    

    
    
    
    

}















