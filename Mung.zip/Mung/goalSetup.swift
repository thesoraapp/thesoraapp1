//
//  goalSetup.swift
//  Mung
//
//  Created by Chike Chiejine on 31/12/2016.
//  Copyright © 2016 Color & Space. All rights reserved.
//

import Foundation
import UIKit
import Parse


class goalsSetupClass {
    

    var goalCategory: String?
    var goalTitle : String?
    var goalImageURL : String?
    var goalImage = UIImage()
    var goalTags = [WSTag]()
    var goalPrice : Double?
    var goalDuration : String?
    var risk : String?
    

    var objectId = String()
    var goalAuthor: PFUser
    var goalAuthorName = String()
    var goalAuthorProfile = String()
    

    
    init( goalSetupObj_: [String : Any]) {
        
        var goalCategory = goalSetupObj_["user"] as! String
        var goalTitle = goalSetupObj_["goalTitle"] as! String
        var goalImageURL = goalSetupObj_["goalImageUrl"] as! String
        var goalImage = UIImage()
        var goalTags = [WSTag]()
        var goalPrice : Double?
        var goalDuration : String?
        var risk : String?
        
        // var goalObject = ["user": PFUser.current(), "goalCategory": String(), "goalTitle": String(), "goalImageUrl": String(), "goalImage": UIImage(), "goalTags": [WSTag](), "goalPrice": Double(), "goalDuration": String(), "risk": String()] as [String : Any]
        

         self.goalAuthor = goalSetupObj_["user"] as! PFUser
        
         //self.goalImage = goalSetupObj_["goalImagePath"] as! String
       //  self.goalTitle = goalSetupObj_["goalTitle"] as! String
        // self.goalLikeCount = goalSetupObj_["goalLikes"] as! Int
        
        
        //self.objectId = goalObj_["objectId"] as! String
        
        //query user
      //  if let user_ = goalSetupObj_["user"] as?  String {
      //      self.goalAuthorName = user_["userFullName"] as! String
            
        //}
        
        
        // optionals
        
       // self.curUserLikedBool = curUserLikedBool
        
        
        
    }
}
