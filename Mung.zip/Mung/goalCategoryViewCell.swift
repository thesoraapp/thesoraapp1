//
//  goalCategoryViewCell.swift
//  Mung
//
//  Created by Chike Chiejine on 01/11/2016.
//  Copyright © 2016 Color & Space. All rights reserved.
//

import UIKit

class goalCategoryViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var categoryImage: UIImageView!
    @IBOutlet weak var categoryName: UILabel!
    @IBOutlet weak var greenTick: UIImageView!
    
    
    var isselected = false
    
    
    
    
    
}
