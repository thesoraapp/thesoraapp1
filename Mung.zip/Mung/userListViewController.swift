//
//  userListViewController.swift
//  Mung
//
//  Created by Chike Chiejine on 14/10/2016.
//  Copyright © 2016 Color & Space. All rights reserved.
//

import UIKit
import Parse

class userListViewController: UITableViewController {
    
    typealias magicUser = (PFObject, Bool)
    var usersList: [magicUser] = []
    var viewTitle = String()

    
    
    //var isFollowing = [Bool]()
    
    @IBOutlet weak var navTitle: UINavigationItem!

    @IBAction func backButton(_ sender: AnyObject) {
        
        self.navigationController?.popToRootViewController(animated: true)
        
    }
    
    @IBAction func addNewGoal(_ sender: AnyObject) {
    }
    

    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        self.navTitle.title  = viewTitle
        
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 300
        tableView.tableFooterView = UIView()
        
    }
    
        
    func followButton(sender: UIButton){
        // Get index from sender
        
        let indexRow = sender.tag
        
        if let currentUser = PFUser.current() {
            if currentUser == nil {
                //send to login
                let vC = self.storyboard?.instantiateViewController(withIdentifier: "loginView")
                self.show(vC!, sender: self)
            } else {
                if usersList[indexRow].1 == true {
                    let followQuery = PFQuery(className: "follow")
                    followQuery.whereKey("follower", equalTo: PFUser.current()!)
                    
                    followQuery.findObjectsInBackground { (followobjects, error) in
                        if followobjects != nil {
                            for follow_ in followobjects! {
                                follow_.deleteInBackground()
                            }}}
                    usersList[indexRow].1 = false
                    setFollowButton(sender: sender, following: false)
                    
                } else {
                    let followObj = PFObject(className: "follow")
                    followObj["follower"] = PFUser.current()!
                    
                    followObj["following"] = usersList[indexRow].0
                    followObj.saveInBackground()
                    usersList[indexRow].1 = true
                   // self.liked = true
                    
                    //Set up liked button state
                    setFollowButton(sender: sender, following: true)
                }}}}
    
    
    func setFollowButton(sender: UIButton, following: Bool) {
        
        print("testtestUNF1")
        
        if following == true {
            let followingIcon = UIImage(named: "tick-icon.png")
            sender.setTitle("", for: UIControlState.normal)
            sender.frame.size.width = 32
            //                userCell.followButton.frame = CGRect(x: buttonX, y: buttonY, width: 32, height: 32)
            sender.setImage(followingIcon, for: UIControlState.normal)
            //        userCell.followButton.addTarget(self, action: #selector(followUser), for: .touchUpInside)
            sender.backgroundColor = UIColor(red:0.01, green:0.68, blue:0.88, alpha:1.0)

        } else {
            
            let noFollowingIcon = UIImage(named: "plus-icon.png")
            sender.setImage(noFollowingIcon, for: UIControlState.normal)
            sender.backgroundColor = UIColor.clear
            sender.layer.borderColor = UIColor(red:0.80, green:0.80, blue:0.80, alpha:1.0).cgColor
            sender.layer.borderWidth =  1
            sender.tintColor = UIColor(red:0.67, green:0.67, blue:0.67, alpha:1.0)
            sender.setTitle("Follow", for: UIControlState.normal)
        
        }
    }
    
    
    
    
    
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return usersList.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

            let userCell = tableView.dequeueReusableCell(withIdentifier: "user", for: indexPath) as! userViewCell
            let indexrow = indexPath.row
            let userTemp = self.usersList[indexrow].0
        
            userCell.userName.text = userTemp["username"] as! String
        
            let imagePath = URL(string:  userTemp["userImagePath"] as! String)

            URLSession.shared.dataTask(with: imagePath!) { (data, response, error) in
            if error != nil {
            } else {
                DispatchQueue.main.async {
                    userCell.userProfile.image = UIImage(data: data!)
                    }
                }
            }.resume()
            

        
            //add generic function call to set view stuff up
            userCell.followButton.tag = indexrow
            // need to somehow grab the row number
            userCell.followButton.addTarget(self, action:#selector(followButton), for: UIControlEvents.touchUpInside)
        
            if usersList[indexrow].1 == true {
                setFollowButton(sender: userCell.followButton, following: true)
               
            } else {
                    setFollowButton(sender: userCell.followButton, following: false)
            }
        
            return userCell
        
        
        
    }
    
//    URLSession.shared.dataTask(with: self.goalUserProfileURLs[indexPath.row]) { (data, response, error) in
//    if error != nil {
//    } else {
//        DispatchQueue.main.async {
//            cell.goalAuthorProfile.setImage(UIImage(data: data!), for: UIControlState.normal)
//        }
//    }
//    }.resume()



//    // Follow/ Unfollow user action
//
//        // pass some username
//    func incremementFollowers(userObj: PFObject) {
//        userObj.incrementKey("userFollowerCount", byAmount: 1)
//        userObj.saveInBackground()
//    }
//        
//    func addFollowerRel(userFollower: PFObject) {
//        var follow = PFObject(className: "follow")
//        follow["following"] = userFollower
//        follow["follower"] = PFUser.current()?.objectId!
//        follow.saveInBackground()
//    }
//
//    func decremementFollowers(userObj: PFObject) {
//        userObj.incrementKey("userFollowerCount", byAmount: -1)
//        userObj.saveInBackground()
//    }
//
//    func removeFollowerRel(userFollower: PFObject) {
//        var follow = PFQuery(className: "follow")
//        follow.whereKey("follower", equalTo: PFUser.current()!.objectId!)
//        follow.whereKey("following", equalTo: userFollower.objectId!)
//        follow.findObjectsInBackground { (objects, error) in
//            if error == nil {
//                for object in objects! {
//                    object.deleteInBackground()
//                }
//            }
//        }
//    }
//      
//











    
    
    //    func tableView(tableView: UITableView, estimatedHeightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
    //        return UITableViewAutomaticDimension
    //    }
    //
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
     // Delete the row from the data source
     tableView.deleteRows(at: [indexPath], with: .fade)
     } else if editingStyle == .insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
