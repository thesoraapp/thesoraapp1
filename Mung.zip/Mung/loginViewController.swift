//
//  loginViewController.swift
//  Mung
//
//  Created by Chike Chiejine on 15/10/2016.
//  Copyright © 2016 Color & Space. All rights reserved.
//

import UIKit
import Parse
import MBProgressHUD

class loginViewController: UITableViewController, UITextFieldDelegate {
    
    /*
 
    Login with Instagram code:
    
     PFCloud.callFunctionInBackground(“functionName”, withParameters: [desireParameters]) { (response, error) in
     if error == nil {
     // The function was successfully executed and you have a correct // response object
     } else {
     // The function returned a error
     }
     }
 
 
 
 
 
 
 
 
    */
    
    
    @IBOutlet weak var userName: UITableViewCell!
    @IBOutlet weak var password: UITableViewCell!
    @IBOutlet weak var facebook: UITableViewCell!
    
    @IBOutlet weak var usernameText: UITextField!
    @IBOutlet weak var passwordText: UITextField!
    
    @IBOutlet weak var userIcon: UIImageView!
    @IBOutlet weak var passwordIcon: UIImageView!
    
    @IBOutlet weak var doneButton: UIBarButtonItem!
    @IBOutlet weak var facebookButton: UIButton!
    @IBOutlet weak var signUp: UIButton!
    
    // Segue variables
    
    var userSegueVal = String()
    var passwordSegueVal =  String()
    
    
    
    @IBAction func facebookButton(_ sender: AnyObject) {
        
    
        let vC = self.storyboard?.instantiateViewController(withIdentifier: "homeView")
        vC?.navigationController?.navigationBar.isHidden = true
        self.show(vC!, sender: self)
        
    }
    
    
    
    @IBAction func donebutton(_ sender: AnyObject) {
        
        if usernameText.text == "" && passwordText.text == "" {
         
            displayAlert("Login Error", message: "Please fill out your login details and try again.")
          
        } else {
            
            activateLogin()
            
            self.doneButton.isEnabled = true
            
            
        }
        
    }
    
    @IBAction func backButton(_ sender: AnyObject) {
        self.navigationController?.popToRootViewController(animated: true)
        
    }

    @IBAction func signUpButton(_ sender: AnyObject) {
        
        let vC = self.storyboard?.instantiateViewController(withIdentifier: "signUpView") as! signUpViewController
        
        print(self.usernameText.text)
        print(self.passwordText.text)
        
        vC.userSegueVal = self.usernameText.text!
        vC.passwordSegueVal = self.passwordText.text!
        
        self.navigationController?.pushViewController(vC, animated: true)
        
        
    }
    
    
    
    override var prefersStatusBarHidden: Bool {
        return false
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationController?.navigationBar.isHidden = false
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        signUp.setTitle("Don't have an account?", for: UIControlState.normal)
        
        facebookButton.backgroundColor = UIColor.clear
        facebookButton.layer.borderColor = UIColor(red:0.84, green:0.82, blue:0.82, alpha:1.0).cgColor
        facebookButton.layer.borderWidth = 1
        facebookButton.layer.cornerRadius = 5
        
        doneButton.isEnabled = false
        
        let tblView =  UIView(frame: CGRect.zero)
        tableView.tableFooterView = tblView

        self.userName.separatorInset = UIEdgeInsets.zero
        self.userName.layoutMargins = UIEdgeInsets.zero
        self.password.separatorInset = UIEdgeInsets.zero
        self.password.layoutMargins = UIEdgeInsets.zero
        
        // Text delegate 
        
        // Set up textfields delegate
        
        self.usernameText.delegate = self
        self.passwordText.delegate = self
        
        self.usernameText.tag = 0
        self.passwordText.tag = 1
        
        
        // Set up keyboard notifications
        
//        NotificationCenter.default.addObserver(self, selector: #selector(loginViewController.keyboardDidShow(_:)), name: NSNotification.Name.UIKeyboardDidShow, object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(loginViewController.keyboardWillBeHidden(_:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
//        

        
        
    
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        self.usernameText.becomeFirstResponder()
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        
        self.view.endEditing(true)
        
        
    }
    
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        if (indexPath as NSIndexPath).row == 3 {
            
            
            tableView.separatorStyle = .none
            
        }
        
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    
        
        if (indexPath as NSIndexPath).row == 0 {
            
            userName.becomeFirstResponder()
            userIcon.tintColor = UIColor(red:0.01, green:0.68, blue:0.88, alpha:1.0)
            passwordIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0)
            
        } else if (indexPath as NSIndexPath).row == 1 {
            
            password.becomeFirstResponder()
            passwordIcon.tintColor = UIColor(red:0.01, green:0.68, blue:0.88, alpha:1.0)
            userIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0)
        }
        
        
    }
  
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        activateLogin()
        
        return true
        
    }
    
    
//    func registerForKeyboardNotifications()
//    {
//        //Adding notifies on keyboard appearing
//        NotificationCenter.default.addObserver(self, selector: "keyboardWasShown:", name: NSNotification.Name.UIKeyboardWillShow, object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(loginViewController.keyboardWillBeHidden(_:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
//    }
//    
//    
//    func deregisterFromKeyboardNotifications()
//    {
//        //Removing notifies on keyboard appearing
//        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillShow, object: nil)
//        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
//    }


    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        print("BEGIN EDITING")
        
        if textField.tag == 0 {
            
            userIcon.tintColor = UIColor(red:0.01, green:0.68, blue:0.88, alpha:1.0)
            passwordIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0)
            
        } else {
            
            passwordIcon.tintColor = UIColor(red:0.01, green:0.68, blue:0.88, alpha:1.0)
            userIcon.tintColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0)
            
        }
        
        if usernameText.text != "" || passwordText.text  != "" {
            
            self.doneButton.isEnabled = true
            
        }
        
        
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if usernameText.text != "" || passwordText.text  != "" {
            
            self.doneButton.isEnabled = true
            
        }
        
        return true
        
    }
    
    
    
    
    
    
    // Display alerts
    
    
    func displayAlert(_ title: String,message: String) {
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
            
            // self.dismissViewControllerAnimated(true, completion: nil)
            
            alert.dismiss(animated: true, completion: nil)
            
        }))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    // Email test
    
    func isValidEmail(_ email:String) -> Bool {
        
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        
        let result = emailTest.evaluate(with: email)
        
        return result
        
    }
    
    
    func activateLogin(){
    
        
        print("login")
        
//        isValidEmail(self.usernameText.text!)
        
        // Validate User input
        
        var errorMessage = "Please try again later"
        
        
        let spinningActivity = MBProgressHUD.showAdded(to: self.view, animated: true)
        
        spinningActivity?.labelText = "Logging In"
        spinningActivity?.isUserInteractionEnabled = false
        
        
        if self.usernameText.text == "" || self.passwordText.text == "" {
            
            displayAlert("Log In Error", message: "Your E-mail, Username or Password is empty. Please check and try again.")
            
            spinningActivity?.isUserInteractionEnabled = true
            spinningActivity?.isHidden = true
            
            
        } /* else if !isValidEmail(email.text!) {
             
             
             displayAlert("E-mail Error", message: "There is something wrong with you e-mail address. please check and try again.")
             
         } */ else  {
            
            // AFTER validation stuff
            
            
            let userName = usernameText.text!
            let password = passwordText.text!
            
            
          
            
            PFUser.logInWithUsername(inBackground: userName, password: password, block: { (user, error) -> Void in
                
                
                spinningActivity?.isUserInteractionEnabled = false
                
                
                if user != nil {
                    
                    print("Logged In")
                    
                    spinningActivity?.isUserInteractionEnabled = true
                    spinningActivity?.isHidden = true
                    
                    // Stop activity indicator whilst user is being signed up
                    let vC = self.storyboard?.instantiateViewController(withIdentifier: "home")
                    self.view.resignFirstResponder()
                    self.view.endEditing(true)

                    let appDelegate = UIApplication.shared.delegate as! AppDelegate
                    appDelegate.window?.rootViewController = vC
            
                } else {
                    
                    
                    if let errorString = error?.localizedDescription {

                        errorMessage = errorString
              
                    
                    spinningActivity?.isUserInteractionEnabled = true
                    spinningActivity?.isHidden = true
                    
                    self.displayAlert("Login Error", message: errorMessage)
                        
                    } // Unwrap error
                    
                    
                }
                
                
                
            })
 
            
        }

        
        
        
        
        
        
        
    }
    
    
//    
//    override func viewDidDisappear(_ animated: Bool) {
//        
//        
//        self.navigationController?.navigationBar.isHidden = true
//        
//        
//        
//    }
//    

    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    
    
    
    
    
    

}
