//
//  goalsSetupViewController.swift
//  Mung
//
//  Created by Chike Chiejine on 01/11/2016.
//  Copyright © 2016 Color & Space. All rights reserved.
//

import UIKit
import Parse

// UIColor(red:0.76, green:0.76, blue:0.76, alpha:1.0) - Next button grey

class goalsSetupViewController: UITableViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    
    //var goalObject = ["user": PFUser.current(), "goalCategory": String(), "goalTitle": String(), "goalImageUrl": String(), "goalImage": UIImage(), "goalTags": [WSTag](), "goalPrice": Double(), "goalDuration": String(), "risk": String()] as [String : Any]
    
    var goalObject : goalsClass
    
    @IBOutlet private weak var categoryCollectionView: UICollectionView!
  
    @IBAction func cancelButton(_ sender: Any) {
        
    
//        self.navigationController?.popToRootViewController(animated: true)
        
//        self.navigationController?.popViewController(animated: true)
        
        self.dismiss(animated: true, completion: nil)
        
        
    }
    
    var categoryName = ["Travel",
                        "Start-up",
                        "Fashion",
                        "Money",
                        "Hobbies"]
    
    var categoryImage = ["travel-icon",
                         "startup-icon",
                         "fashion-icon",
                         "money-icon",
                         "other-icon"]
    
    var selected = false
    let nextButton = UIButton()

    override func viewDidLoad() {
        super.viewDidLoad()

      //  self.navigationController?.navigationBar.barTintColor = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0
        
        self.tableView.tableFooterView = UIView()
        
        // Setup Next Button
        
        nextButton.setTitle("Next Step", for: UIControlState.normal)
        nextButton.tintColor = UIColor(red:0.13, green:0.13, blue:0.13, alpha:1.0)
        nextButton.isEnabled  = false
        nextButton.backgroundColor = UIColor(red:0.76, green:0.76, blue:0.76, alpha:1.0)
        nextButton.frame = CGRect(x: 0, y: self.view.frame.height - 55, width: self.view.frame.width, height: 55)
        nextButton.addTarget(self, action: #selector(self.nextButtonAction), for: UIControlEvents.touchUpInside)

    }
    
    
    func nextButtonAction(sender: UIButton) {
        
        let indexPath = sender.tag
        let nextvC = self.storyboard?.instantiateViewController(withIdentifier: "step2") as! goalsSetup2ViewController
        nextvC.goalObject = self.goalObject
        self.show(nextvC, sender: self)
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        
//        self.view.addSubview(nextButton)
        let windowCount = UIApplication.shared.windows.count
        UIApplication.shared.windows[windowCount-1].addSubview(nextButton)
        
        print(goalObject)
        
        // self.goalObject["goalCategory"] = self.goalObject["goalCategory"]
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        nextButton.removeFromSuperview()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        if indexPath.row == 0 {
            
            cell.separatorInset = UIEdgeInsets.zero
            cell.indentationWidth = 0
            cell.layoutMargins = UIEdgeInsets.zero
            tableView.separatorStyle = .singleLine
            
        }
        
        tableView.separatorStyle = .none
        
    }

    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        
        return categoryName.count
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        var cell = collectionView.dequeueReusableCell(withReuseIdentifier: "categoryCell", for: indexPath) as! goalCategoryViewCell

        cell.categoryName.text = self.categoryName[indexPath.item].uppercased()
        cell.categoryImage.image = UIImage(named: self.categoryImage[indexPath.item])
        cell.greenTick.isHidden = true
        
        
        if self.goalObject.goalCategory == self.categoryName[indexPath.item] {
            
            cell.greenTick.isHidden = false
            self.nextButton.backgroundColor = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0) //Light blue
            self.nextButton.isEnabled = true
            
        } else {
            
            cell.greenTick.isHidden = true

            
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        collectionView.allowsMultipleSelection = false
        let cell = collectionView.cellForItem(at: indexPath)  as! goalCategoryViewCell
        
        // nextButton.isHidden = false

        nextButton.tag = indexPath.item
        cell.greenTick.isHidden = true
        
        
        if cell.isselected == false {
        
            cell.greenTick.isHidden = false
            
            self.goalObject.goalCategory = self.categoryName[indexPath.item]
            
            
            self.nextButton.backgroundColor = UIColor(red:0.20, green:0.68, blue:0.89, alpha:1.0) //Light blue
            self.nextButton.isEnabled = true
            
            cell.isselected = true

            
        } else {
            
            
            cell.greenTick.isHidden = false
            
            cell.greenTick.isHidden = true
            self.goalObject.goalCategory  = ""
            
            self.nextButton.backgroundColor = UIColor(red:0.76, green:0.76, blue:0.76, alpha:1.0)
            self.nextButton.isEnabled = false
            
            cell.isselected = false
            
            
        }
    }
}
