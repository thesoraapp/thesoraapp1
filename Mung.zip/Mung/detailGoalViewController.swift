//
//  detailGoalViewController.swift
//  Mung
//
//  Created by Chike Chiejine on 05/10/2016.
//  Copyright © 2016 Color & Space. All rights reserved.
//

import UIKit
import Parse

class detailGoalViewController: UITableViewController {
    
    
    
    
    @IBOutlet weak var goalImage: UIImageView!
    @IBOutlet weak var goalTitle: UILabel!
    
    // Cell one
    
    @IBOutlet weak var goalProgress: KDCircularProgress!
    @IBOutlet weak var goalCurrentAmount: UILabel!
    @IBOutlet weak var goalTimeLeft: UILabel!
    @IBOutlet weak var goalCompletionPercentage: UILabel!
    
    // Cell two
    
    @IBOutlet weak var goalTargetAmount: UILabel!
    
    //Cell Three
    
    @IBOutlet weak var goalLatestDeposit: UILabel!
    
    
    
    
    // Goal index
    
    
    
    // Data
//    
//    var goalImageURLs = [String]()
//    var goalTitles = [String]()
//    var goalTotalSaved = [Float]()
//    var goalCurAlloc = [Int]()
//    var goalRemainAmount = [Double]()
//    var goalCurTimeLeft = [Double]()
//    var goalPrettyTimeLeft = [String]()
//    var goalEndDate = [Date] ()
//    var goalCurDepositRate = [Int]()
//    var percAngle: Double?
//    var goalPercComplete = [Double]()
//    var prevGoal: PFObject?
//    
    
    // Cell one variables
    var gImageURL : URL?
    var gTitle = String()
    var goalCurrent =  String()
    var goalTime = String()
    var goalPerc = String()
    var percAngle = Double()
    var selectedGoal : PFObject?
    var goalCurDepositRate: Int?
    var goalEndDate: Date?
    
    // Cell two variables
    
    var goalTarget = Double()

    
    // Cell three variables
    
    var latestDeposit = Int()

    
    @IBOutlet var summaryCell: [UITableViewCell]!

    let overlayGradient = CAGradientLayer()
    
    
    func goBack() {
        
        print("SHOULDGOBACK")
        self.navigationController?.popViewController(animated: true)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("LOADED VIEW")
        
        //Add backbutton
        
        helpers().backButton(sender: self)
        

        //Gradient Overlay
        
        overlayGradient.colors = [UIColor.clear.cgColor, UIColor.black.cgColor]
        overlayGradient.locations = [0.0, 0.9]
        overlayGradient.frame = CGRect(x: 0, y: 2, width: goalImage.frame.width + 40, height: goalImage.frame.height)
        goalImage.layer.insertSublayer(overlayGradient, at: 0)
        
        // Table Footer
        
        helpers().tableFooter(sender: self)
        
 
        for cell in summaryCell {
            
            if cell.tag != 0 {
            
            cell.separatorInset = UIEdgeInsets.zero
            cell.layoutMargins = UIEdgeInsets.zero
                
            }
            
        }
        
        
        // Set up variables 

        if let imageprofile1 = self.gImageURL {
            
            self.goalImage.af_setImage(withURL: imageprofile1, placeholderImage: UIImage(named:"no-image-bg"), filter: nil,imageTransition: .crossDissolve(0.2), runImageTransitionIfCached: true, completion: nil)
            
        }
        
        self.goalTitle.text = self.gTitle
        self.goalCurrentAmount.text = self.goalCurrent
        self.goalTimeLeft.text = self.goalTime
        self.goalCompletionPercentage.text = self.goalPerc
        self.goalProgress.animate(fromAngle: 0, toAngle: self.percAngle, duration: 2, completion: nil)
        
        
        self.goalTargetAmount.text = String(self.goalTarget)
        self.goalLatestDeposit.text = String(self.latestDeposit)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        print("SELECTEDGOALDEETS")
        print(selectedGoal)
        
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        
        if indexPath.row == 3  {
            
            
            let vC = self.storyboard?.instantiateViewController(withIdentifier: "step3") as! goalsSetup3ViewController
            
            vC.goalCurDepositRate = self.goalCurDepositRate
            vC.goalTarget = self.goalTarget
            vC.goalEndDate = self.goalEndDate
            vC.selectedGoal = self.selectedGoal
            vC.editMode = true
            self.show(vC, sender: self)
            
        }
        
        
    }


    
    
    @IBAction func likeButton(_ sender: UIButton) {
        
//        // Get index from sender
//        let indexRow = sender.tag
//        if let currentUser = PFUser.current() {
//            if currentUser == nil {
//                //send to login
//                let vC = self.storyboard?.instantiateViewController(withIdentifier: "loginView")
//                self.show(vC!, sender: self)
//            } else {
//                if isLiked[indexRow] == true {
//                    let likedQuery = PFQuery(className: "likes")
//                    likedQuery.whereKey("likeUserParent", equalTo: PFUser.current()!)
//                    likedQuery.whereKey("likeGoalParent", equalTo: discGoals[indexRow].goalObj!)
//                    likedQuery.findObjectsInBackground { (goalobjects, error) in
//                        if goalobjects != nil {
//                            for goal_ in goalobjects! {
//                                goal_.deleteInBackground()
//                            }}}
//                    isLiked[indexRow] = false
//                    self.liked = false
//                    let likedButton = UIImage(named: "linedHeart-icon.png")
//                    sender.setImage(likedButton, for: UIControlState.normal)
//                } else {
//                    let likeObj = PFObject(className: "likes")
//                    likeObj["likeUserParent"] = PFUser.current()!
//                    likeObj["likeGoalParent"] = self.discGoals[indexRow].goalObj!
//                    likeObj.saveInBackground()
//                    isLiked[indexRow] = true
//                    self.liked = true
//                    
//                    //Set up liked button state
//                    
//                    let likedButton = UIImage(named: "filledHeart-icon.png")?.withRenderingMode(.alwaysTemplate)
//                    sender.tintColor = UIColor(red:0.90, green:0.04, blue:0.20, alpha:1)
//                    sender.setImage(likedButton, for: UIControlState.normal)
//                }}}
        
    }
    
    
    @IBAction func commentButton(_ sender: UIButton) {
        
        let nextvC = self.storyboard?.instantiateViewController(withIdentifier: "commentsView") as! commentsViewController
         nextvC.selectedGoal = self.selectedGoal
   
        self.show(nextvC, sender: self)
        
    }



    @IBAction func shareGoal(_ sender: UIButton) {
        
        
        // Get index from sender
        
        let indexRow = sender.tag
        
        
        let textToShare = "Swift is awesome!  Check out this website about it!"
        if let myWebsite = NSURL(string: "http://www.codingexplorer.com/")
        {
            let objectsToShare = [textToShare, myWebsite] as [Any]
            let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
            
            //            //New Excluded Activities Code
            //            activityVC.excludedActivityTypes = [UIActivityTypeAirDrop, UIActivityTypeAddToReadingList]
            //            //
            
            self.present(activityVC, animated: true, completion: nil)
            
        }

        
        
    }
  

    
    
    
    
    
    
    
    
    
    
    
    
    
    

  
}
