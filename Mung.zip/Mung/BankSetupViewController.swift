//
//  BankSetupViewController.swift
//  Mung
//
//  Created by Jake Dorab on 11/21/16.
//  Copyright © 2016 Color & Space. All rights reserved.
//

import Foundation
import Parse
//import plaid_ios_sdk
import UIKit
import WebKit
import Alamofire
import SwiftyJSON

class BankSetupViewController: UIViewController, UIWebViewDelegate, WKNavigationDelegate {
    
    
        var goalObject = ["user": PFUser.current(), "goalCategory": String(), "goalTitle": String(), "goalImageUrl": String(), "goalImage": UIImage(), "goalTags": [WSTag](), "goalPrice": Double(), "goalDuration": String(), "risk": String()] as [String : Any]

        @IBOutlet var containerView : UIView? = nil
        
        var webView: WKWebView!
        
        override func loadView() {
            self.webView = WKWebView()
            self.webView.navigationDelegate = self
            self.view = webView
        }
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            // load the link url
            let linkUrl = generateLinkInitializationURL()
            let url = URL(string: linkUrl)
            let request = URLRequest(url:url! as URL)
            self.webView.load(request as URLRequest)
            self.webView.allowsBackForwardNavigationGestures = false
        }
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }
        
        // getUrlParams :: parse query parameters into a Dictionary
        func getUrlParams(_ url: URL) -> Dictionary<String, String> {
            var paramsDictionary = [String: String]()
            let queryItems = URLComponents(string: (url.absoluteString))?.queryItems
            queryItems?.forEach { paramsDictionary[$0.name] = $0.value }
            return paramsDictionary
        }
        
        // generateLinkInitializationURL :: create the link.html url with query parameters
        func generateLinkInitializationURL() -> String {
            let config = [
                "key": "f8cd9a6cb9e34bce6b79d4b7025f25",
                "product": "connect",
                "longtail": "true",
                "selectAccount": "true",
                "env": "tartan",
                "clientName": "Mung",
                "webhook": "https://requestb.in",
                "isMobile": "true",
                "isWebview": "true"
            ]
            
            // Build a dictionary with the Link configuration options
            // See the Link docs (https://plaid.com/docs/link) for full documentation.
            var components = URLComponents()
            components.scheme = "https"
            components.host = "cdn.plaid.com"
            components.path = "/link/v2/stable/link.html"
            components.queryItems = config.map { (URLQueryItem(name: $0, value: $1) as URLQueryItem) }
            return components.string!
        }
    

    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping ((WKNavigationActionPolicy) -> Void)) {
        
            let linkScheme = "plaidlink";
            let actionScheme = navigationAction.request.url?.scheme;
            let actionType = navigationAction.request.url?.host;
            let queryParams = getUrlParams(navigationAction.request.url!)
            
            if (actionScheme == linkScheme) {
                switch actionType {
                    
                case "connected"?:
                    // Close the webview
                    self.dismiss(animated: true, completion: nil)
                    
                    // Parse data passed from Link into a dictionary
                    // This includes the public_token as well as account and institution metadata
                    print("Public Token: \(queryParams["public_token"])");
                    print("Account ID: \(queryParams["account_id"])");
                    print("Institution type: \(queryParams["institution_type"])");
                    print("Institution name: \(queryParams["institution_name"])");

                    // HERE
                    
                    // stripe configuration
                    
                    let publicToken = queryParams["public_token"] ?? ""
                    let accountID = queryParams["account_id"] ?? ""
                    
                    
                    let config = [
                        "client_id": "58323031a753b969cf26fb75",
                        "secret": "ca152607993354abddc89ab75e0a83",
                        "public_token": publicToken,
                        "account_id": accountID
                    ]
                    
                    
                    var components = URLComponents()
                    components.scheme = "https"
                    components.host = "tartan.plaid.com"
                    components.path = "/exchange_token"
                    components.queryItems = config.map { (URLQueryItem(name: $0, value: $1) as URLQueryItem) }
                    
                    if let url = URL(string: components.string!)! as? URL {
                        var request = URLRequest(url:url)
                        
                        request.httpMethod = "POST"
                        let b =  Alamofire.request(request).responseJSON {
                        
                            result in
                            switch result.result {
                            case .success(let jsonObject):
                                let json = JSON(jsonObject)
                                print("JSON")
                                print(json)
                                
                                func generateLinkInitializationURLGetTransactions() -> String {
                                    let config = [
                                        "client_id": "58323031a753b969cf26fb75",
                                        "secret": "ca152607993354abddc89ab75e0a83",
                                        "access_token": json["access_token"].rawString() ?? "something_went_wrong"
                                    ]
                                    
                                    // Build a dictionary with the Link configuration options
                                    // See the Link docs (https://plaid.com/docs/link) for full documentation.
                                    var components = NSURLComponents(string: "https://tartan.plaid.com/connect")!

                                    components.queryItems = config.map { URLQueryItem(name: $0, value: $1) }
                                    return components.string!
                                }
                                
                                let linkUrl2 = generateLinkInitializationURLGetTransactions()
                                let url2 = NSURL(string: linkUrl2)
                                var request2 = URLRequest(url:url2! as URL)
                                request2.httpMethod = "GET"

                                    let b =  Alamofire.request(request2).responseJSON { result2 in
                                
                                
                                    switch result2.result {
                                    case .success(let jsonObject2):
                                        let json2 = JSON(jsonObject2)
                                        print(json2)
                                    case .failure:
                                        print("HELLO999")
                                        break
                                        }}
                                    
                                
                            case .failure:
                                print("HELLO123")
                                break
                            }
                        }
                    }

                    
                    break
                case "exit"?:
                    // Close the webview
                    self.dismiss(animated: true, completion: nil)
                    
                    // Parse data passed from Link into a dictionary
                    // This includes information about where the user was in the Link flow
                    // any errors that occurred, and request IDs
                    print("URL: \(navigationAction.request.url?.absoluteString)")
                    // Output data from Link
                    print("User status in flow: \(queryParams["status"])");
                    // The requet ID keys may or may not exist depending on when the user exited
                    // the Link flow.
                    print("Link request ID: \(queryParams["link_request_id"])");
                    print("Plaid API request ID: \(queryParams["link_request_id"])");
                    break
                    
                default:
                    print("Link action detected: \(actionType)")
                    break
                }
                
                decisionHandler(.cancel)
            } else if (navigationAction.navigationType == WKNavigationType.linkActivated &&
                (actionScheme == "http" || actionScheme == "https")) {
                // Handle http:// and https:// links inside of Plaid Link,
                // and open them in a new Safari page. This is necessary for links
                // such as "forgot-password" and "locked-account"
                UIApplication.shared.openURL(navigationAction.request.url!)
                decisionHandler(.cancel)
            } else {
                print("Unrecognized URL scheme detected that is neither HTTP, HTTPS, or related to Plaid Link: \(navigationAction.request.url?.absoluteString)");
                decisionHandler(.allow)
            }
        }
    
    
//    let plaid = Plaid()
//    
//    
//    
//    @IBOutlet weak var webView: UIWebView!
//    
//
//    
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        
//        
//
//        
//        let url = Bundle.main.url(forResource: "Plaid", withExtension: "html")
//        let request = URLRequest(url: url!)
//        webView.loadRequest(request)
//
//        
//        plaid.setPublicKey("f8cd9a6cb9e34bce6b79d4b7025f25")
//        
//        
//        
//        
////        plaid.addLinkUser(for: "auth", username: String!, password: <#T##String!#>, type: <#T##String!#>, options: <#T##[AnyHashable : Any]!#>, completion: <#T##PlaidMfaCompletion!##PlaidMfaCompletion!##(PLDAuthentication?, Any?, Error?) -> Void#>) {
////            
////        }
//        
//        
////        "https://cdn.plaid.com/link/stable/link-initialize.js"
//        
////        var linkHandler = Plaid.create({
////            env: "tartan",
////            clientName: "Stripe / Plaid Test",
////            key: "f8cd9a6cb9e34bce6b79d4b7025f25",
////            product: "auth",
////            selectAccount: true,
////            onSuccess: function(public_token, metadata) {
////                // Send the public_token and account ID to your app server.
////                console.log("public_token: " + public_token);
////                console.log("account ID: " + metadata.account_id)
////            }
////        })
//
//    }
//
//
//}
}
