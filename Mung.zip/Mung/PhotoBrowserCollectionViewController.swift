//
//  PhotoBrowserCollectionViewController.swift
//  Mung
//
//  Created by Jake Dorab on 11/6/16.
//  Copyright © 2016 Color & Space. All rights reserved.
//


import UIKit
import Foundation
import CoreData
import Alamofire
import SwiftyJSON
import FastImageCache
import Parse
import AlamofireImage


class PhotoBrowserCollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout, UIViewControllerTransitioningDelegate {
    
    
        var goalObject = ["user": PFUser.current(), "goalCategory": String(), "goalTitle": String(), "goalImageUrl": String(), "goalImage": UIImage(), "goalTags": [WSTag](), "goalPrice": Double(), "goalDuration": String(), "risk": String()] as [String : Any]
    
    @IBOutlet weak var cancelButton: UIBarButtonItem!
    
    @IBAction func cancelButtonAction(_ sender: Any) {
        
        
        self.dismiss(animated: true, completion: nil)


        
    }

    
    
    
    let formatName = KMSmallImageFormatName
    var shouldLogin = false
    
    
    var user = PFUser.current()
    
    var photos = [PhotoInfo]()
    let refreshControl = UIRefreshControl()
    var populatingPhotos = false
    var nextURLRequest: NSURLRequest?
    var coreDataStack: CoreDataStack!
    
    let PhotoBrowserCellIdentifier = "PhotoBrowserCell"
    let PhotoBrowserFooterViewIdentifier = "PhotoBrowserFooterView"
    
    // MARK: Life-cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
        
        print("VIEWDIDLOAD12322")
        print("currentUSER777")
        print(PFUser.current())
        
        // handleRefresh()
        
//        if let fetchRequest = coreDataStack.model.fetchRequestTemplate(forName: "UserFetchRequest") {
//            
//            let results = try! coreDataStack.context.fetch(fetchRequest) as! [User]
//            user = results.first
//        }
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        print("viewdidappear!!!")
        print(shouldLogin)
        print("shouldLoginEND")
        
        print("userUSER")
        print(user)
        print("userUSEREND")

        if user != nil {
            
            print("testtest123LOGGEDIN")
            print(user)
            handleRefresh()
        } else {
            
            print("testtest123LOGGEDIN")
            print(user)

            shouldLogin = true
        }

        if shouldLogin {
            print("Logged In")
            let vC = self.storyboard?.instantiateViewController(withIdentifier: "instaLoginRoot")
            self.show(vC!, sender: self)
            shouldLogin = false
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func unwindToPhotoBrowser (segue : UIStoryboardSegue) {
        
    }
    
    // MARK: CollectionView
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photos.count
    }
    
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        

        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: PhotoBrowserCellIdentifier, for: indexPath as IndexPath) as! PhotoBrowserCollectionViewCell
        let sharedImageCache = FICImageCache.shared()
        cell.imageView.image = nil
        
     
        
        let photo = photos[indexPath.row] as PhotoInfo
        
        print("PhotoInfoPrint")
        print(photo)
        print("PhotoInfoPrintEND")

        
//        if (cell.photoInfo != photo) {
//            
//            print("CANCELLEDPHOTO")
//            
//            sharedImageCache?.cancelImageRetrieval(for: cell.photoInfo, withFormatName: formatName)
//            
//            cell.photoInfo = photo
//        }
        

        // cell.imageView.af_setImage(withURL: photo.sourceImageURL)
        // print("requesting image from: \((photo.sourceImageURL as URL).absoluteString)")
        cell.imageView.af_setImage(withURL: photo.sourceImageURL as URL) { _ in
            // print("got result from: \((photo.sourceImageURL as URL).absoluteString)")
        }
//        sharedImageCache?.retrieveImage(for: photo, withFormatName: formatName, completionBlock: {
//            (photoInfo, _, image) in
//            
//            print("ImageCacheTest")
//            
//            if (photoInfo as! PhotoInfo) == cell.photoInfo {
//                
//                print("ImagePrint")
//                print(image)
//                print("ImagePrintEND")
//                
//                cell.imageView.image = image
//                
//                
//                
//            }
//        })
        
        return cell
        
        
    }
    
    
//    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
//        print("indexPathMain")
//        print(indexPath)
//        print("indexPathMainEnd")
//        
//        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: PhotoBrowserCellIdentifier, for: indexPath as IndexPath) as! PhotoBrowserCollectionViewCell
//        let sharedImageCache = FICImageCache.shared()
//        cell.imageView.image = nil
//        
//        print("indexPATHrow")
//        print(indexPath.row)
//        print("indexPATHrowEND")
//        
//        let photo = photos[indexPath.row] as PhotoInfo
//        if (cell.photoInfo != photo) {
//            
//            sharedImageCache?.cancelImageRetrieval(for: cell.photoInfo, withFormatName: formatName)
//            
//            cell.photoInfo = photo
//        }
//        
//        sharedImageCache?.retrieveImage(for: photo, withFormatName: formatName, completionBlock: {
//            (photoInfo, _, image) -> Void in
//            if (photoInfo as! PhotoInfo) == cell.photoInfo {
//                cell.imageView.image = image
//            }
//        })
//        
//        return cell
//    }
    
    func collectionView(collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, atIndexPath indexPath: NSIndexPath) -> UICollectionReusableView {
        let footerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: PhotoBrowserFooterViewIdentifier, for: indexPath as IndexPath) as! PhotoBrowserLoadingCollectionView
        if nextURLRequest == nil {
            footerView.spinner.stopAnimating()
        } else {
            footerView.spinner.startAnimating()
        }
        return footerView
    }
    
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    
        let photoInfo = photos[indexPath.row]
        
        
       let vC = storyboard?.instantiateViewController(withIdentifier: "step2") as! goalsSetup2ViewController
       self.goalObject["goalImageURL"] = photoInfo.sourceImageURL.absoluteString
        vC.goalObject = self.goalObject
        

        
        print("TRANSITION2")
        
        self.show(vC, sender: self)
        
        
        
        
    }
    
    
    
    func setupCollectionViewLayout() {
        let layout = UICollectionViewFlowLayout()
        let column = UI_USER_INTERFACE_IDIOM() == .pad ? 4 : 3
        let itemWidth = floor((view.bounds.size.width - CGFloat(column - 1)) / CGFloat(column))
        layout.itemSize = CGSize(width: itemWidth, height: itemWidth)
        layout.minimumInteritemSpacing = 1.0
        layout.minimumLineSpacing = 1.0
        layout.footerReferenceSize = CGSize(width: collectionView!.bounds.size.width, height: 100.0)
        collectionView!.collectionViewLayout = layout
    }
    
    func setupView() {
        setupCollectionViewLayout()
        collectionView!.register(PhotoBrowserCollectionViewCell.classForCoder(), forCellWithReuseIdentifier: PhotoBrowserCellIdentifier)
        collectionView!.register(PhotoBrowserLoadingCollectionView.classForCoder(), forSupplementaryViewOfKind: UICollectionElementKindSectionFooter, withReuseIdentifier: PhotoBrowserFooterViewIdentifier)
        
        refreshControl.tintColor = UIColor.white
        refreshControl.addTarget(self, action: #selector(handleRefresh), for: .valueChanged)
        collectionView!.addSubview(refreshControl)
    }
    
    
    override func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        if (self.nextURLRequest != nil && scrollView.contentOffset.y + view.frame.size.height > scrollView.contentSize.height * 0.8) {
            populatePhotos(request: self.nextURLRequest! as! URLRequestConvertible)
        }
    }
    
    
    
    func populatePhotos(request: URLRequestConvertible) {
        
        if populatingPhotos {
            return
        }
        
        populatingPhotos = true
        
        print("RequestNumber2")
        print(request)
        print("RequestNumber2END")
        
        Alamofire.request(request).responseJSON {
            result in
            
            print("RESULTPHOTOS")
            //print(result.result.value!)
            print(result.data)
            print("RESULTPHOTOSEND")
            
            defer {
                self.populatingPhotos = false
            }
            switch result.result {
            case .success(let jsonObject):
                //debugPrint(jsonObject)
                let json = JSON(jsonObject)
            
            
                print("JSONRESULTS")
                print(json)
                print("JSONRESULTSEND")
            
            
                if (json["meta"]["code"].intValue  == 200) {
                    
                    //DispatchQueue.global().async {
                        //  dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0))
                        DispatchQueue.global(priority: DispatchQueue.GlobalQueuePriority.high).async() {
                    //DispatchQueue.global(DispatchQueue.GlobalQueuePriority.high, 0).asynchronously()
                        
                            
       // don't have to deal with pagination in sandbox mode
//                        if let urlString = json["pagination"]["next_url"].URL {
//                            self.nextURLRequest = NSURLRequest(url: urlString)
//                            
//                            print("urlStringHELLO")
//                            print(urlString)
//                            print("urlStringHELLOEND")
//                            
//                        } else {
//                            self.nextURLRequest = nil
//                        }
                        let photoInfos = json["data"].arrayValue
                            .filter {
                                $0["type"].stringValue == "image"
                            }.map({
                                PhotoInfo(sourceImageURL: $0["images"]["standard_resolution"]["url"].URL! as NSURL)
                            })
                            
                            print("photoInfosHELLO")
                            print(photoInfos)
                            print("photoInfosHELLOEND")
                            
                        let lastItem = self.photos.count
                            
                        print("lastItem")
                        print(lastItem)
                            
                        self.photos.append(contentsOf: photoInfos)
                        
                        print("photoscountNow")
                        print((lastItem..<self.photos.count))
                            
                        let indexPaths = (lastItem..<self.photos.count).map { IndexPath(row: $0, section: 0) }
                        
                        print("indexPaths")
                        print(indexPaths)
                        print("indexPathsEND")
                            
                        DispatchQueue.main.async() {
                            self.collectionView!.insertItems(at: indexPaths)
                        }
                        
                    }
                    
                }
            case .failure:
                break
            }
            
        }
    }
    
    func handleRefresh() {
        
        print("testadmin1")
        
        nextURLRequest = nil
        refreshControl.beginRefreshing()
        self.photos.removeAll(keepingCapacity: false)
        self.collectionView!.reloadData()
        refreshControl.endRefreshing()
        
        // this was user != nil
        if user != nil {
            
            print("TRIGGERED")
            let currentUser = PFUser.current()
            let accessTokenINSTA = currentUser!["userInstagramAccessToken"]
           // let accessTokenINSTA = Parse.User.current()!.get("userInstagramUserName")
                
                
        
            print(currentUser!["userInstagramAccessToken"])
            
            //can't access userInstagramUserName in currentUser so writing this weird function
            
            let string1 = currentUser!["username"] as! String
            let index1 = string1.index(string1.endIndex, offsetBy: -4)
            
            let userNameINSTA = string1.substring(to: index1)
            
            //can't access userInstagramUserName in currentUser so writing this weird function
            
            
            
            let request = Instagram.Router.PopularPhotos(userNameINSTA as! String, accessTokenINSTA as! String)
            
            print("RequestHELLO")
            print(request)
            
            populatePhotos(request: request)
        }
    }
    

    
    func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if (segue.identifier == "show photo" && segue.destination is PhotoViewerViewController) {
            let photoViewerViewController = segue.destination as! PhotoViewerViewController
         //   photoViewerViewController.photoInfo = sender?.value("photoInfo") as? PhotoInfo
            
       //     photoViewerViewController.photoInfo = sender?["photoInfo"] as? PhotoInfo
            
        } else if (segue.identifier == "login" && segue.destination is UINavigationController) {
            let navigationController = segue.destination as! UINavigationController
            if let oauthLoginViewController = navigationController.topViewController as? OauthLoginViewController {
                oauthLoginViewController.coreDataStack = coreDataStack
            }
            
           // if self.user != nil {
               // coreDataStack.context.delete(user!)
              //  coreDataStack.saveContext()
                
           // }
        }
    }
}
class PhotoBrowserCollectionViewCell: UICollectionViewCell {
    let imageView = UIImageView()
    var photoInfo: PhotoInfo?
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        backgroundColor = UIColor(white: 0.1, alpha: 1.0)
        
        imageView.frame = bounds
        addSubview(imageView)
    }
}

class PhotoBrowserLoadingCollectionView: UICollectionReusableView {
    let spinner = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.whiteLarge)
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        spinner.startAnimating()
        spinner.center = self.center
        addSubview(spinner)
    }
}
