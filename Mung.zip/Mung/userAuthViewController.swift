//
//  userAuthViewController.swift
//  Mung
//
//  Created by Chike Chiejine on 15/10/2016.
//  Copyright © 2016 Color & Space. All rights reserved.
//

import Foundation
import Parse



class userAuthViewController: UIViewController {
    
    @IBOutlet weak var backgroundImage: UIImageView!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var signUpButton: UIButton!
    @IBOutlet weak var mungMotto: UILabel!
    @IBOutlet weak var logo: UIImageView!
    
    
    @IBAction func signupButton(_ sender: AnyObject) {

        let vC = self.storyboard?.instantiateViewController(withIdentifier: "loginView")
        self.navigationController?.show(vC!, sender: self)
        
    }
    
    
    @IBAction func logInButton(_ sender: AnyObject) {
        
        let vC = self.storyboard?.instantiateViewController(withIdentifier: "instaLogin")
        self.navigationController?.show(vC!, sender: self)
        
        
    }

    let overlayGradient = CAGradientLayer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        

        
        
        logo.image = UIImage(named: "logo-sora.pdf")
        logo.layer.masksToBounds = true
        
        mungMotto.text = "INVEST IN YOUR DREAMS"
        
        
        backgroundImage.image = UIImage(named: "festival.jpg")
        loginButton.layer.cornerRadius = 5
        signUpButton.layer.cornerRadius = 5
        
        
        //Gradient Overlay
        
        let width = self.view.frame.width
        let height = self.view.frame.height
        
        overlayGradient.colors = [UIColor.clear.cgColor, UIColor(red:0.01, green:0.11, blue:0.23, alpha:1.0).cgColor]
        overlayGradient.locations = [0.0, 0.7]
        overlayGradient.frame = CGRect(x: 0, y: 0, width: width, height: height)
        self.backgroundImage.layer.insertSublayer(overlayGradient, at: 0)
        
    
        
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        
        print(self.view.frame.width)
        
        // Do any additional setup after loading the view.
        
        let buttonWidth = loginButton.frame.width
        let buttonHeight = loginButton.frame.height
        let buttonImageHeight = (loginButton.imageView?.frame.height)! / 2
        let yCenter = (buttonHeight / 2) + buttonImageHeight
        let xPos = 15

        
    
        
        if self.view.frame.width == 320 {
            
            loginButton.titleEdgeInsets = UIEdgeInsetsMake(yCenter, -18, yCenter, 10)
            
            let buttonImageWidth = (loginButton.imageView?.frame.width)!
            let yCenter = (buttonHeight / 2) + buttonImageHeight
            let xPos = buttonWidth - buttonImageWidth - 30
            loginButton.imageEdgeInsets = UIEdgeInsetsMake(yCenter, xPos, yCenter, 0)
            
        }
    
        if self.view.frame.width == 375 {
            
            loginButton.titleEdgeInsets = UIEdgeInsetsMake(yCenter, -10, yCenter, 0)
            
            let buttonImageWidth = (loginButton.imageView?.frame.width)!
            let yCenter = (buttonHeight / 2) + buttonImageHeight
            let xPos = buttonWidth - buttonImageWidth - 15
            loginButton.imageEdgeInsets = UIEdgeInsetsMake(yCenter, xPos, yCenter, 0)
            
        }
        
        if self.view.frame.width == 414 {
            
            let buttonImageWidth = (loginButton.imageView?.frame.width)!
            let yCenter = (buttonHeight / 2) + buttonImageHeight
            let xPos = buttonWidth - buttonImageWidth - 10
            loginButton.imageEdgeInsets = UIEdgeInsetsMake(yCenter, xPos, yCenter, 0)
            
            
        }
        
        
        
        
        
        self.navigationController?.navigationBar.isHidden = true

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


    
    
    
    /*
     
     FIRAuth.auth()!.signIn(withEmail: textFieldLoginEmail.text!, password: textFieldLoginPassword.text!)
     
     
     FIRAuth.auth()!.addStateDidChangeListener() { auth, user in
     
     if user != nil {
     
     self.performSegue(withIdentifier: self.loginToList, sender: nil)
     }
     }
     
     
     FIRAuth.auth()?.addAuthStateDidChangeListener { auth, user in
     if let user = user {
     // User is signed in.
     } else {
     // No user is signed in.
     }
     }
     
     
     if let user = FIRAuth.auth()?.currentUser {
     let name = user.displayName
     let email = user.email
     let photoUrl = user.photoURL
     let uid = user.uid;  // The user's ID, unique to the Firebase project.
     // Do NOT use this value to authenticate with
     // your backend server, if you have one. Use
     // getTokenWithCompletion:completion: instead.
     } else {
     // No user is signed in.
     }
     
     //TODO
     */

    
    

    
    
    
    
    
    

}
